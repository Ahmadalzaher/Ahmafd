<?php
/**
 * WooVina Customizer Class
 *
 * @package WooVina WordPress theme
 */

if(! defined('ABSPATH')) {
	exit;
}

if(! class_exists('WooVina_Customizer')) :

	/**
	 * The WooVina Customizer class
	 */
	class WooVina_Customizer {

		/**
		 * Setup class.
		 *
		 * @since 1.0
		 */
		public function __construct() {

			add_action('customize_register',					array($this, 'custom_controls'));
			add_action('customize_register',					array($this, 'controls_helpers'));
			add_action('customize_register',					array($this, 'customize_register'), 11);
			add_action('after_setup_theme',					array($this, 'register_options'));
			add_action('customize_preview_init', 				array($this, 'customize_preview_init'));
			add_action('customize_controls_enqueue_scripts', 	array($this, 'custom_customize_enqueue'), 7);

		}

		/**
		 * Adds custom controls
		 *
		 * @since 1.0.0
		 */
		public function custom_controls($wp_customize) {

			// Path
			$dir = WOOVINA_INC_DIR . 'customizer/controls/';

			// Load customize control classes
			require_once($dir . 'buttonset/class-control-buttonset.php' 					);
			require_once($dir . 'color/class-control-color.php' 							);		
			require_once($dir . 'dimensions/class-control-dimensions.php' 					);
			require_once($dir . 'dropdown-pages/class-control-dropdown-pages.php' 			);
			require_once($dir . 'heading/class-control-heading.php' 						);
			require_once($dir . 'icon-select/class-control-icon-select.php' 				);
			require_once($dir . 'multicheck/class-control-multicheck.php' 					);
			require_once($dir . 'multiple-select/class-control-multiple-select.php' 		);
			require_once($dir . 'radio-image/class-control-radio-image.php' 				);
			require_once($dir . 'range/class-control-range.php' 							);
			require_once($dir . 'slider/class-control-slider.php' 							);
			require_once($dir . 'sortable/class-control-sortable.php' 						);
			require_once($dir . 'text/class-control-text.php' 								);
			require_once($dir . 'textarea/class-control-textarea.php' 						);
			require_once($dir . 'typo/class-control-typo.php' 								);
			require_once($dir . 'typography/class-control-typography.php' 					);

			// Register JS control types
			$wp_customize->register_control_type('WooVina_Customizer_Buttonset_Control' 		);
			$wp_customize->register_control_type('WooVina_Customizer_Color_Control' 			);
			$wp_customize->register_control_type('WooVina_Customizer_Dimensions_Control' 		);
			$wp_customize->register_control_type('WooVina_Customizer_Dropdown_Pages' 			);
			$wp_customize->register_control_type('WooVina_Customizer_Heading_Control' 			);
			$wp_customize->register_control_type('WooVina_Customizer_Icon_Select_Control' 		);
			$wp_customize->register_control_type('WooVina_Customize_Multicheck_Control' 		);
			$wp_customize->register_control_type('WooVina_Customize_Multiple_Select_Control' 	);
			$wp_customize->register_control_type('WooVina_Customizer_Range_Control' 			);
			$wp_customize->register_control_type('WooVina_Customizer_Slider_Control' 			);
			$wp_customize->register_control_type('WooVina_Customizer_Radio_Image_Control' 		);
			$wp_customize->register_control_type('WooVina_Customizer_Sortable_Control' 		);
			$wp_customize->register_control_type('WooVina_Customizer_Text_Control' 			);
			$wp_customize->register_control_type('WooVina_Customizer_Textarea_Control' 		);
			$wp_customize->register_control_type('WooVina_Customizer_Typo_Control' 			);
			$wp_customize->register_control_type('WooVina_Customizer_Typography_Control' 		);

		}

		/**
		 * Adds customizer helpers
		 *
		 * @since 1.0.0
		 */
		public function controls_helpers() {
			require_once(WOOVINA_INC_DIR .'customizer/customizer-helpers.php');
			require_once(WOOVINA_INC_DIR .'customizer/sanitization-callbacks.php');
		}

		/**
		 * Core modules
		 *
		 * @since 1.0.0
		 */
		public static function customize_register($wp_customize) {

			// Tweak default controls
			$wp_customize->get_setting('blogname')->transport 		= 'postMessage';
			$wp_customize->get_setting('blogdescription')->transport 	= 'postMessage';

			// Move custom logo setting
			$wp_customize->get_control('custom_logo')->section 		= 'woovina_header_logo';

		}

		/**
		 * Adds customizer options
		 *
		 * @since 1.0.0
		 */
		public function register_options() {
			
			// Var
			$dir = WOOVINA_INC_DIR .'customizer/settings/';

			// Customizer files array
			$files = array(
				'general',
				'typography',
				'topbar',
				'header',
				'blog',
				'sidebar',
				'footer-widgets',
				'footer-bottom',
			);

			foreach ($files as $key) {

				$setting = str_replace('-', '_', $key);

				// If WooVina Extra is activated
				if(WOOVINA_EXTRA_ACTIVE
					&& class_exists('WooVina_Extra_Theme_Panel')) {

					if(WooVina_Extra_Theme_Panel::get_setting('we_'. $setting .'_panel')) {
						require_once($dir . $key .'.php');
					}

				} else {

					require_once($dir . $key .'.php');

				}

			}

			// If WooCommerce is activated
			if(WOOVINA_WOOCOMMERCE_ACTIVE) {
				require_once($dir .'woocommerce.php');
			}

		}

		/**
		 * Loads js file for customizer preview
		 *
		 * @since 1.0.0
		 */
		public function customize_preview_init() {
			wp_enqueue_script('woovina-customize-preview', WOOVINA_INC_DIR_URI . 'customizer/assets/js/customize-preview.min.js', array('customize-preview'), WOOVINA_THEME_VERSION, true);
		}

		/**
		 * Load scripts for customizer
		 *
		 * @since 1.0.0
		 */
		public function custom_customize_enqueue() {
			wp_enqueue_style('font-awesome', WOOVINA_CSS_DIR_URI .'devs/font-awesome.min.css', false, '4.7.0');
			wp_enqueue_style('simple-line-icons', WOOVINA_INC_DIR_URI .'customizer/assets/css/customizer-simple-line-icons.min.css', false, '2.4.0');
			wp_enqueue_style('woovina-general', WOOVINA_INC_DIR_URI . 'customizer/assets/min/css/general.min.css');
			wp_enqueue_script('woovina-general', WOOVINA_INC_DIR_URI . 'customizer/assets/min/js/general.min.js', array('jquery', 'customize-base'), false, true);

			if(is_rtl()) {
				wp_enqueue_style('woovina-controls-rtl', WOOVINA_INC_DIR_URI . 'customizer/assets/min/css/rtl.min.css');
			}
		}

	}

endif;

return new WooVina_Customizer();
