<?php
/**
 * Rhythm game.
 *
 * @package Yalla
 */

$beats = yd_beats();
$total = count( $beats );
?>
<section class="section game" id="rhythmus">
	<div class="container game__grid">
		<div class="reveal">
			<p class="eyebrow"><?php echo esc_html( yd_t( 'game_eyebrow' ) ); ?></p>
			<h2><?php echo esc_html( yd_t( 'game_title' ) ); ?></h2>
			<p class="lede mt-2"><?php echo esc_html( yd_t( 'game_text' ) ); ?></p>

			<div class="btn-row mt-3">
				<a class="btn" href="<?php echo esc_url( yd_link( 'program' ) ); ?>"><?php echo esc_html( yd_t( 'game_cta' ) ); ?></a>
				<a class="btn btn--ghost" href="<?php echo esc_url( yd_link( 'contact' ) ); ?>"><?php echo esc_html( yd_t( 'cta_button' ) ); ?></a>
			</div>

			<p class="small muted mt-3"><?php echo esc_html( yd_t( 'game_footnote' ) ); ?></p>
		</div>

		<div class="game__box reveal" data-rhythm-game>
			<div class="game__top">
				<span class="tiny"><?php echo esc_html( yd_t( 'game_cta2' ) ); ?></span>
				<span class="game__status">
					<i aria-hidden="true"></i>
					<span data-game-state><?php echo esc_html( yd_t( 'game_ready' ) ); ?></span>
				</span>
			</div>

			<figure class="game__figure">
				<img data-game-image src="<?php echo esc_url( $beats[0]['image'] ); ?>" alt="<?php echo esc_attr( $beats[0]['alt'] ); ?>" width="960" height="540" loading="lazy" decoding="async" />
				<span class="game__badge" data-game-badge aria-hidden="true">1</span>
				<figcaption class="game__caption" data-game-caption><?php echo esc_html( $beats[0]['name'] ); ?></figcaption>
			</figure>

			<div class="game__stage" data-game-stage>
				<?php for ( $step = 1; $step <= 16; $step++ ) : ?>
					<button class="beat" type="button" data-step="<?php echo esc_attr( $step - 1 ); ?>" aria-label="<?php echo esc_attr( yd_t( 'game_beat' ) . ' ' . $step ); ?>">
						<?php echo esc_html( $step ); ?>
					</button>
				<?php endfor; ?>
			</div>

			<div class="game__controls">
				<button class="btn btn--light" type="button" data-game-play><?php echo esc_html( yd_t( 'game_listen' ) ); ?></button>
				<button class="btn btn--outline-light" type="button" data-game-next><?php echo esc_html( yd_t( 'game_next' ) ); ?></button>
			</div>

			<div class="game__meta">
				<span class="game__name" data-game-name><?php echo esc_html( $beats[0]['name'] ); ?></span>
				<span>
					<?php echo esc_html( yd_t( 'game_beat' ) ); ?>
					<span data-game-index>1</span>
					<?php echo esc_html( yd_t( 'game_of' ) ); ?>
					<?php echo esc_html( $total ); ?>
				</span>
			</div>

			<p class="small mt-2" style="color:#a9977f;margin:0;"><?php echo esc_html( yd_t( 'game_hint' ) ); ?></p>
		</div>
	</div>
</section>
