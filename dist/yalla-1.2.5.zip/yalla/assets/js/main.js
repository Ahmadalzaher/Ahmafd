/**
 * Yalla Arab Kulturfestival — front-end behaviour.
 * Vanilla JS, no dependencies.
 */
(function () {
	'use strict';

	var config = window.YallaConfig || {};

	/* ---------------------------------------------------------- header -- */
	var header = document.getElementById('site-header');
	if (header) {
		var onScroll = function () {
			header.classList.toggle('is-stuck', window.scrollY > 8);
		};
		onScroll();
		window.addEventListener('scroll', onScroll, { passive: true });
	}

	/* ------------------------------------------------------ mobile nav -- */
	var toggle = document.querySelector('.nav-toggle');
	var mobileNav = document.getElementById('mobile-nav');

	function closeNav() {
		document.body.classList.remove('nav-open', 'is-locked');
		if (toggle) {
			toggle.setAttribute('aria-expanded', 'false');
		}
	}

	if (toggle) {
		toggle.addEventListener('click', function () {
			var open = document.body.classList.toggle('nav-open');
			document.body.classList.toggle('is-locked', open);
			toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
			if (open && mobileNav) {
				var firstLink = mobileNav.querySelector('a');
				if (firstLink) {
					firstLink.focus({ preventScroll: true });
				}
			}
		});
	}

	if (mobileNav) {
		mobileNav.addEventListener('click', function (event) {
			if (event.target.closest('a')) {
				closeNav();
			}
		});
	}

	/* ------------------------------------------------------- reveal in -- */
	var revealItems = document.querySelectorAll('.reveal');
	if (revealItems.length) {
		if ('IntersectionObserver' in window) {
			var observer = new IntersectionObserver(
				function (entries) {
					entries.forEach(function (entry) {
						if (entry.isIntersecting) {
							entry.target.classList.add('is-in');
							observer.unobserve(entry.target);
						}
					});
				},
				{ rootMargin: '0px 0px -8% 0px', threshold: 0.08 }
			);
			revealItems.forEach(function (item) {
				observer.observe(item);
			});
		} else {
			revealItems.forEach(function (item) {
				item.classList.add('is-in');
			});
		}
	}

	/* ---------------------------------------------------- video modal -- */
	var modal = document.getElementById('video-modal');
	var modalBody = document.getElementById('video-modal-body');

	function closeModal() {
		if (!modal) {
			return;
		}
		modal.classList.remove('is-open');
		modal.setAttribute('aria-hidden', 'true');
		document.body.classList.remove('is-locked');
		if (modalBody) {
			modalBody.innerHTML = '';
		}
	}

	if (modal) {
		document.addEventListener('click', function (event) {
			var trigger = event.target.closest('[data-yd-video]');
			if (trigger) {
				event.preventDefault();
				var id = trigger.getAttribute('data-yd-video');
				if (!id || !modalBody) {
					return;
				}
				// No YouTube request without explicit consent.
				if (!window.ydConsent || !window.ydConsent.isGranted()) {
					if (window.ydConsent) {
						window.ydConsent.open('prompt');
					}
					return;
				}
				var iframe = document.createElement('iframe');
				iframe.src = 'https://www.youtube-nocookie.com/embed/' + encodeURIComponent(id) + '?autoplay=1&rel=0';
				iframe.title = 'YouTube';
				iframe.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture';
				iframe.allowFullscreen = true;
				modalBody.appendChild(iframe);
				modal.classList.add('is-open');
				modal.setAttribute('aria-hidden', 'false');
				document.body.classList.add('is-locked');
				var closeBtn = modal.querySelector('.modal__close');
				if (closeBtn) {
					closeBtn.focus({ preventScroll: true });
				}
				return;
			}

			if (event.target.closest('[data-close-modal]')) {
				closeModal();
			}
		});

		document.addEventListener('keydown', function (event) {
			if ('Escape' === event.key) {
				closeModal();
			}
		});
	}

	/* --------------------------------------------------- rhythm game --- */
	var game = document.querySelector('[data-rhythm-game]');
	if (game) {
		var beats = Array.isArray(config.beats) ? config.beats : [];
		var boxes = Array.prototype.slice.call(game.querySelectorAll('.beat'));
		var stateEl = game.querySelector('[data-game-state]');
		var nameEl = game.querySelector('[data-game-name]');
		var indexEl = game.querySelector('[data-game-index]');
		var imageEl = game.querySelector('[data-game-image]');
		var badgeEl = game.querySelector('[data-game-badge]');
		var captionEl = game.querySelector('[data-game-caption]');
		var playBtn = game.querySelector('[data-game-play]');
		var nextBtn = game.querySelector('[data-game-next]');
		var strings = config.strings || {};

		var current = 0;
		var running = false;
		var timers = [];
		var audio = null;
		var fadeTimer = null;

		function context() {
			if (audio) {
				return audio;
			}
			var AudioCtx = window.AudioContext || window.webkitAudioContext;
			if (!AudioCtx) {
				return null;
			}
			try {
				audio = new AudioCtx();
			} catch (error) {
				audio = null;
			}
			return audio;
		}

		function tone(step) {
			var ctx = context();
			if (!ctx) {
				return;
			}
			if (ctx.state === 'suspended' && ctx.resume) {
				ctx.resume();
			}
			var now = ctx.currentTime;
			var osc = ctx.createOscillator();
			var gain = ctx.createGain();
			var accent = 0 === step % 4;

			osc.type = accent ? 'triangle' : 'sine';
			osc.frequency.value = accent ? 196 : 392;
			gain.gain.setValueAtTime(0.0001, now);
			gain.gain.exponentialRampToValueAtTime(accent ? 0.28 : 0.18, now + 0.01);
			gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.16);

			osc.connect(gain);
			gain.connect(ctx.destination);
			osc.start(now);
			osc.stop(now + 0.18);
		}

		function clearTimers() {
			timers.forEach(function (timer) {
				window.clearTimeout(timer);
			});
			timers = [];
		}

		function reset() {
			clearTimers();
			running = false;
			boxes.forEach(function (box) {
				box.classList.remove('is-on', 'is-next');
			});
			if (stateEl) {
				stateEl.textContent = strings.ready || 'Ready';
			}
			if (playBtn) {
				playBtn.textContent = strings.listen || 'Listen';
			}
		}

		function hit(box) {
			if (!box) {
				return;
			}
			box.classList.add('is-on');
			window.setTimeout(function () {
				box.classList.remove('is-on');
			}, 130);
		}

		function currentBeat() {
			return beats[current] || null;
		}

		function updateLabels() {
			var beat = currentBeat();
			if (beat && nameEl) {
				nameEl.textContent = beat.name;
			}
			if (indexEl) {
				indexEl.textContent = String(current + 1);
			}
			if (badgeEl) {
				badgeEl.textContent = String(current + 1);
			}
			if (captionEl && beat) {
				captionEl.textContent = beat.name;
			}
			if (imageEl && beat && beat.image && imageEl.getAttribute('src') !== beat.image) {
				imageEl.classList.add('is-fading');
				window.clearTimeout(fadeTimer);
				fadeTimer = window.setTimeout(function () {
					imageEl.src = beat.image;
					imageEl.alt = beat.alt || beat.name;
					var reveal = function () {
						imageEl.classList.remove('is-fading');
						imageEl.removeEventListener('load', reveal);
					};
					if (imageEl.complete) {
						reveal();
					} else {
						imageEl.addEventListener('load', reveal);
					}
				}, 160);
			}
		}

		function play() {
			var beat = currentBeat();
			if (!beat || !Array.isArray(beat.steps)) {
				return;
			}

			reset();
			running = true;
			if (stateEl) {
				stateEl.textContent = beat.name;
			}
			if (playBtn) {
				playBtn.textContent = strings.again || 'Again';
			}

			var stepMs = 190;
			beat.steps.forEach(function (on, step) {
				if (!on) {
					return;
				}
				timers.push(
					window.setTimeout(function () {
						hit(boxes[step]);
						tone(step);
					}, step * stepMs)
				);
			});

			timers.push(
				window.setTimeout(function () {
					running = false;
					if (stateEl) {
						stateEl.textContent = strings.ready || 'Ready';
					}
				}, beat.steps.length * stepMs + 220)
			);
		}

		function next() {
			if (!beats.length) {
				return;
			}
			current = (current + 1) % beats.length;
			updateLabels();
			play();
		}

		boxes.forEach(function (box) {
			box.addEventListener('click', function () {
				var step = parseInt(box.getAttribute('data-step'), 10) || 0;
				hit(box);
				tone(step);
			});
		});

		if (playBtn) {
			playBtn.addEventListener('click', function () {
				if (running) {
					reset();
				} else {
					play();
				}
			});
		}

		if (nextBtn) {
			nextBtn.addEventListener('click', next);
		}

		// Preload the stills so switching moves does not flicker.
		beats.forEach(function (beat) {
			if (beat.image) {
				var preload = new Image();
				preload.src = beat.image;
			}
		});

		updateLabels();
	}

	/* --------------------------------------------- smooth anchor links -- */
	document.addEventListener('click', function (event) {
		var link = event.target.closest('a[href^="#"]');
		if (!link) {
			return;
		}
		var id = link.getAttribute('href');
		if (!id || '#' === id.length) {
			return;
		}
		var target = document.querySelector(id);
		if (!target) {
			return;
		}
		event.preventDefault();
		target.scrollIntoView({ behavior: 'smooth', block: 'start' });
		window.history.replaceState(null, '', id);
	});
})();
