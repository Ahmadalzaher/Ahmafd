<?php
/**
 * Yalla Engage mobile app (PWA) – rendered by YENA_App.
 *
 * @var array $app Configuration prepared by YENA_App::maybe_serve().
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?><!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#12332c">
<meta name="robots" content="noindex,nofollow">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="Yalla">
<link rel="manifest" href="<?php echo esc_url( $app['manifest'] ); ?>">
<link rel="apple-touch-icon" href="<?php echo esc_url( $app['icon'] ); ?>">
<title>Yalla Engage</title>
<style>
:root{--bg:#f4f1ea;--card:#fff;--ink:#1c2b27;--muted:#6b7a75;--brand:#12332c;--gold:#e8c872;--ok:#1e7a46;--okbg:#e3f4ea;--warn:#9a6a00;--warnbg:#fff3d6;--bad:#b3261e;--badbg:#fde8e6;--line:#e3ded2}
@media (prefers-color-scheme:dark){:root{--bg:#0f1715;--card:#18231f;--ink:#e9efec;--muted:#93a39d;--line:#27352f;--okbg:#12301f;--warnbg:#3a2f0e;--badbg:#3a1613}}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;height:100%}
body{font-family:system-ui,-apple-system,"Segoe UI",Roboto,"Noto Naskh Arabic","Noto Sans Arabic",Tahoma,sans-serif;background:var(--bg);color:var(--ink);font-size:16px;line-height:1.5}
#app{min-height:100%;display:flex;flex-direction:column;padding-top:env(safe-area-inset-top,0px)}
header{background:var(--brand);color:#fff;padding:14px 16px;display:flex;align-items:center;gap:10px;position:sticky;top:0;z-index:5}
header h1{font-size:18px;margin:0;flex:1}
header .sub{font-size:12px;opacity:.75}
main{flex:1;padding:14px 14px 96px;max-width:720px;width:100%;margin:0 auto}
nav{position:fixed;bottom:0;left:0;right:0;background:var(--card);border-top:1px solid var(--line);display:flex;padding-bottom:env(safe-area-inset-bottom,0px);z-index:6}
nav button{flex:1;border:0;background:none;color:var(--muted);padding:9px 2px 7px;font:inherit;font-size:12px;display:flex;flex-direction:column;align-items:center;gap:2px;cursor:pointer}
nav button .ic{font-size:22px;line-height:1}
nav button.on{color:var(--brand);font-weight:700}
@media (prefers-color-scheme:dark){nav button.on{color:var(--gold)}}
.card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:14px;margin-bottom:12px}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.stat{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:12px}
.stat b{display:block;font-size:26px;line-height:1.1}
.stat span{color:var(--muted);font-size:13px}
h2{font-size:15px;margin:18px 2px 8px;color:var(--muted);font-weight:600}
input,select,button.btn{font:inherit}
input[type=text],input[type=search],input[type=password],select{width:100%;padding:12px;border:1px solid var(--line);border-radius:12px;background:var(--card);color:var(--ink)}
.row{display:flex;gap:8px;margin-bottom:10px}
.row>*{flex:1}
button.btn{border:0;border-radius:12px;background:var(--brand);color:#fff;padding:13px 16px;font-weight:700;cursor:pointer;width:100%}
button.btn.alt{background:transparent;color:var(--brand);border:1px solid var(--line)}
@media (prefers-color-scheme:dark){button.btn{background:var(--gold);color:#12332c}button.btn.alt{color:var(--ink)}}
button.btn:disabled{opacity:.5}
.badge{display:inline-block;padding:2px 9px;border-radius:99px;font-size:12px;font-weight:700;background:var(--line);color:var(--ink)}
.badge.ok{background:var(--okbg);color:var(--ok)}.badge.warn{background:var(--warnbg);color:var(--warn)}.badge.bad{background:var(--badbg);color:var(--bad)}
.item{display:block}
.item .top{display:flex;justify-content:space-between;gap:8px;align-items:flex-start}
.item .name{font-weight:700;word-break:break-word}
.item .meta{color:var(--muted);font-size:13px;margin-top:2px;word-break:break-word}
.item a{color:inherit}
.muted{color:var(--muted)}
.center{text-align:center}
.msg{padding:12px;border-radius:12px;margin-bottom:12px;background:var(--badbg);color:var(--bad)}
#video{width:100%;aspect-ratio:1/1;object-fit:cover;background:#000;border-radius:14px;display:block}
.vwrap{position:relative;margin-bottom:10px}
.vwrap:after{content:"";position:absolute;inset:18%;border:3px solid var(--gold);border-radius:18px;pointer-events:none;opacity:.9}
.res{border-radius:14px;padding:16px;margin:10px 0}
.res.ok{background:var(--okbg);color:var(--ok)}.res.warn{background:var(--warnbg);color:var(--warn)}.res.bad{background:var(--badbg);color:var(--bad)}
.res h3{margin:0 0 6px;font-size:20px}
.res .info{color:var(--ink);font-size:15px}
.stepper{display:flex;align-items:center;justify-content:center;gap:18px;margin:12px 0}
.stepper button{width:46px;height:46px;border-radius:50%;border:1px solid var(--line);background:var(--card);color:var(--ink);font-size:24px}
.stepper b{font-size:26px;min-width:36px;text-align:center}
.login{max-width:420px;margin:7vh auto 0;padding:0 16px}
.login h1{text-align:center;margin:10px 0 4px}
.login p{color:var(--muted);font-size:14px}
.hide{display:none!important}
nav button{position:relative}
nav .nb{position:absolute;top:3px;inset-inline-start:calc(50% + 6px);min-width:18px;height:18px;border-radius:9px;background:var(--bad);color:#fff;font-size:11px;font-weight:700;line-height:18px;padding:0 4px;text-align:center}
#toast{position:fixed;top:calc(env(safe-area-inset-top,0px) + 8px);left:10px;right:10px;z-index:20;background:var(--brand);color:#fff;border-radius:14px;padding:12px 14px;box-shadow:0 6px 24px rgba(0,0,0,.35);transform:translateY(-140%);transition:transform .25s}
#toast.show{transform:none}
@media (prefers-color-scheme:dark){#toast{background:var(--gold);color:#12332c}}
.newbox{border-color:var(--gold);border-width:2px}
.newbox h3{margin:0 0 8px;font-size:16px}
label.opt{display:flex;gap:10px;align-items:center;padding:6px 0}
</style>
</head>
<body>
<div id="app"></div>
<script src="<?php echo esc_url( $app['jsqr'] ); ?>"></script>
<script>
(function () {
'use strict';
var CFG = <?php echo wp_json_encode( $app, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ); ?>;
var root = document.getElementById('app');
try { var apiU = new URL(CFG.api, location.href); CFG.api = location.origin + apiU.pathname + apiU.search; } catch (e) {}
var auth = null, me = null, events = [], tab = 'home';
var cursor = null, unread = [], pollTimer = null, polling = false, prefs = {sound: true, notify: false};

var ST_REG = {confirmed:['مؤكد','ok'], checked_in:['حضر','ok'], pending_payment:['بانتظار الدفع','warn'], cancelled:['ملغى','bad'], refunded:['مُسترد','bad']};
var ST_SUB = {confirmed:['مؤكد','ok'], pending:['بانتظار التأكيد','warn'], unsubscribed:['ألغى الاشتراك','bad']};

/* ---------- helpers ---------- */
function el(tag, attrs) {
  var n = document.createElement(tag);
  if (attrs) Object.keys(attrs).forEach(function (k) {
    var v = attrs[k];
    if (v === null || v === undefined || v === false) return;
    if (k === 'class') n.className = v;
    else if (k === 'text') n.textContent = v;
    else if (k.indexOf('on') === 0) n.addEventListener(k.slice(2), v);
    else n.setAttribute(k, v === true ? '' : v);
  });
  for (var i = 2; i < arguments.length; i++) {
    var c = arguments[i];
    if (c === null || c === undefined || c === false) continue;
    n.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
  }
  return n;
}
function clear(n) { while (n.firstChild) n.removeChild(n.firstChild); return n; }
function fmt(s) {
  if (!s) return '';
  var d = new Date(String(s).replace(' ', 'T') + 'Z');
  if (isNaN(d)) return s;
  return d.toLocaleString([], {dateStyle: 'short', timeStyle: 'short'});
}
function badge(map, key) {
  var m = map[key] || [key || '—', ''];
  return el('span', {class: 'badge ' + m[1], text: m[0]});
}
function debounce(fn, ms) { var t; return function () { var a = arguments, c = this; clearTimeout(t); t = setTimeout(function () { fn.apply(c, a); }, ms); }; }

function loadAuth() { try { auth = JSON.parse(localStorage.getItem('yena_auth') || 'null'); } catch (e) { auth = null; } }
function saveAuth(a) { auth = a; try { if (a) localStorage.setItem('yena_auth', JSON.stringify(a)); else localStorage.removeItem('yena_auth'); } catch (e) {} }
function loadState() {
  try { var c = localStorage.getItem('yena_cursor'); cursor = c ? parseInt(c, 10) : null; } catch (e) { cursor = null; }
  try { unread = JSON.parse(localStorage.getItem('yena_unread') || '[]'); if (!Array.isArray(unread)) unread = []; } catch (e) { unread = []; }
  try { var p = JSON.parse(localStorage.getItem('yena_prefs') || '{}'); if (p && typeof p === 'object') { if (typeof p.sound === 'boolean') prefs.sound = p.sound; if (typeof p.notify === 'boolean') prefs.notify = p.notify; } } catch (e) {}
}
function saveState() {
  try {
    if (cursor !== null) localStorage.setItem('yena_cursor', String(cursor));
    localStorage.setItem('yena_unread', JSON.stringify(unread.slice(-50)));
    localStorage.setItem('yena_prefs', JSON.stringify(prefs));
  } catch (e) {}
}
function clearState() { cursor = null; unread = []; try { localStorage.removeItem('yena_cursor'); localStorage.removeItem('yena_unread'); } catch (e) {} }
function b64(str) { return btoa(unescape(encodeURIComponent(str))); }

function api(path, opt) {
  opt = opt || {};
  var url = CFG.api + path;
  if (opt.params) {
    var q = new URLSearchParams();
    Object.keys(opt.params).forEach(function (k) { var v = opt.params[k]; if (v !== '' && v !== null && v !== undefined) q.append(k, v); });
    var s = q.toString();
    if (s) url += (url.indexOf('?') > -1 ? '&' : '?') + s;
  }
  var token = b64(auth.u + ':' + auth.p);
  var headers = {'X-Yena-Auth': token, 'Authorization': 'Basic ' + token};
  var init = {method: opt.method || 'GET', headers: headers, cache: 'no-store'};
  if (opt.body) { headers['Content-Type'] = 'application/json'; init.body = JSON.stringify(opt.body); }
  return fetch(url, init).then(function (r) {
    return r.json().catch(function () { return {}; }).then(function (data) {
      if (r.status === 401 || r.status === 403) { var e = new Error('auth'); e.auth = true; e.reason = (data && data.data && data.data.reason) || ''; throw e; }
      if (!r.ok) { var e2 = new Error((data && data.message) || ('HTTP ' + r.status)); e2.status = r.status; e2.data = data; throw e2; }
      return data;
    });
  });
}
function failure(err) {
  if (err && err.auth) { stopScan(); stopPolling(); saveAuth(null); showLogin('انتهت الجلسة أو بيانات الدخول غير صحيحة.'); return true; }
  return false;
}

/* ---------- login ---------- */
function reasonText(r) {
  var m = {
    bad_credentials: 'اسم المستخدم أو كلمة مرور التطبيق غير صحيحين. استخدم «كلمة مرور التطبيق» التي أنشأتها من الملف الشخصي، وليس كلمة مرور حسابك. (يمكنك كتابة البريد الإلكتروني بدل اسم المستخدم.)',
    app_passwords_disabled: 'كلمات مرور التطبيقات معطّلة على الموقع (تحتاج HTTPS، أو عطّلتها إضافة أمان أو إعداد الاستضافة).',
    no_capability: 'تم التحقق من الحساب لكن ليس لديه صلاحية إدارة Yalla Engage.',
    header_missing: 'الخادم لا يمرر بيانات الدخول من التطبيق (جدار حماية أو إعداد استضافة يحجب الترويسات).',
    throttled: 'محاولات كثيرة فاشلة. انتظر 15 دقيقة ثم حاول من جديد.',
    bad_format: 'صيغة بيانات الدخول غير صحيحة. أعد كتابتها.',
    unsupported: 'إصدار ووردبريس على الموقع قديم ولا يدعم كلمات مرور التطبيقات.'
  };
  return m[r] || 'تعذر تسجيل الدخول (رفض غير معروف السبب). تأكد من البيانات أو من إعدادات أمان الموقع.';
}
function showLogin(msg) {
  stopScan();
  stopPolling();
  clear(root);
  var user = el('input', {type: 'text', autocomplete: 'username', placeholder: 'اسم المستخدم في ووردبريس', autocapitalize: 'off'});
  var pass = el('input', {type: 'password', autocomplete: 'current-password', placeholder: 'كلمة مرور التطبيق', autocapitalize: 'off'});
  var err = el('div', {class: 'msg' + (msg ? '' : ' hide'), text: msg || ''});
  var btn = el('button', {class: 'btn', text: 'دخول', onclick: submitLogin});
  function submitLogin() {
    var u = user.value.trim(), p = pass.value.replace(/\s+/g, ' ').trim();
    if (!u || !p) { err.textContent = 'أدخل اسم المستخدم وكلمة مرور التطبيق.'; err.classList.remove('hide'); return; }
    btn.disabled = true; err.classList.add('hide');
    auth = {u: u, p: p};
    api('me').then(function (m) { me = m; saveAuth(auth); boot(); })
      .catch(function (e) {
        auth = null; btn.disabled = false;
        err.textContent = e.auth ? reasonText(e.reason) : ('تعذر الاتصال بالموقع (' + CFG.api + '): ' + e.message);
        err.classList.remove('hide');
      });
  }
  root.appendChild(el('div', {class: 'login'},
    el('h1', {text: 'Yalla Engage'}),
    el('p', {class: 'center', text: CFG.site}),
    err,
    el('div', {class: 'card'}, el('div', {class: 'row'}, user), el('div', {class: 'row'}, pass), btn),
    el('p', {},
      'للحصول على كلمة مرور التطبيق: ادخل إلى ووردبريس ← المستخدمون ← الملف الشخصي ← «كلمات مرور التطبيقات»، اكتب اسماً مثل ',
      el('b', {text: 'Yalla App'}), ' ثم اضغط «إضافة». انسخ كلمة المرور الظاهرة والصقها هنا. ',
      el('a', {href: CFG.profile, target: '_blank', rel: 'noopener', text: 'فتح الصفحة'}))
  ));
}

/* ---------- shell ---------- */
var views = {};
function shell() {
  clear(root);
  var title = el('h1', {text: 'Yalla Engage'});
  root.appendChild(el('header', {}, title, el('span', {class: 'sub', text: me ? me.name : ''})));
  var main = el('main', {id: 'main'});
  root.appendChild(main);
  var items = [['home', '📊', 'الرئيسية'], ['scan', '📷', 'مسح'], ['regs', '🎟️', 'التسجيلات'], ['subs', '✉️', 'المشتركون'], ['me', '👤', 'حسابي']];
  var nav = el('nav');
  items.forEach(function (it) {
    nav.appendChild(el('button', {'data-t': it[0], class: it[0] === tab ? 'on' : '', onclick: function () { go(it[0]); }},
      el('span', {class: 'ic', text: it[1]}), it[2]));
  });
  root.appendChild(nav);
}
function go(t) {
  if (tab === 'scan' && t !== 'scan') stopScan();
  tab = t;
  var bs = document.querySelectorAll('nav button');
  for (var i = 0; i < bs.length; i++) bs[i].classList.toggle('on', bs[i].getAttribute('data-t') === t);
  var main = clear(document.getElementById('main'));
  window.scrollTo(0, 0);
  views[t](main);
}

/* ---------- live feed of new registrations ---------- */
function stopPolling() { if (pollTimer) { clearInterval(pollTimer); pollTimer = null; } }
function startPolling() { stopPolling(); poll(); pollTimer = setInterval(poll, 20000); }
function updateBadge() {
  var b = document.querySelector('nav button[data-t=home]');
  if (!b) return;
  var old = b.querySelector('.nb'); if (old) old.remove();
  if (unread.length) b.appendChild(el('span', {class: 'nb', text: unread.length > 99 ? '99+' : String(unread.length)}));
}
function toast(text) {
  var t = document.getElementById('toast');
  if (!t) { t = el('div', {id: 'toast', onclick: function () { t.classList.remove('show'); go('home'); }}); document.body.appendChild(t); }
  t.textContent = text; t.classList.add('show');
  clearTimeout(t._h); t._h = setTimeout(function () { t.classList.remove('show'); }, 7000);
}
function beep() {
  try {
    var A = window.AudioContext || window.webkitAudioContext; if (!A) return;
    var a = new A(), o = a.createOscillator(), g = a.createGain();
    o.type = 'sine'; o.frequency.value = 880; g.gain.value = 0.15; o.connect(g); g.connect(a.destination); o.start();
    setTimeout(function () { try { o.stop(); a.close(); } catch (e) {} }, 220);
  } catch (e) {}
}
function announce(items) {
  var first = items[0];
  var text = items.length === 1 ? ('🔔 تسجيل جديد: ' + first.name + ' — ' + first.event + ' (' + first.persons + ')') : ('🔔 ' + items.length + ' تسجيلات جديدة');
  toast(text);
  if (prefs.sound) beep();
  if (navigator.vibrate) navigator.vibrate([120, 60, 120]);
  if (prefs.notify && document.hidden && 'Notification' in window && Notification.permission === 'granted' && navigator.serviceWorker) {
    navigator.serviceWorker.getRegistration().then(function (reg) {
      if (reg) reg.showNotification('Yalla Engage', {body: text.replace('🔔 ', ''), icon: CFG.icon, tag: 'yena-new', renotify: true, dir: 'rtl', lang: 'ar', data: {url: CFG.start}});
    }).catch(function () {});
  }
}
function poll() {
  if (!auth || !me || polling) return;
  polling = true;
  api('registrations/feed', {params: {after_id: cursor === null ? 0 : cursor}}).then(function (d) {
    polling = false;
    var firstRun = (cursor === null);
    cursor = d.cursor; 
    if (!firstRun && d.items && d.items.length) {
      var known = {};
      unread.forEach(function (u) { known[u.id] = true; });
      var fresh = d.items.filter(function (it) { return !known[it.id]; });
      unread = unread.concat(fresh).slice(-50);
      saveState(); updateBadge();
      if (fresh.length) { announce(fresh); if (tab === 'home') go('home'); }
    } else { saveState(); }
  }).catch(function (e) { polling = false; failure(e); });
}
document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'visible') poll(); });

/* ---------- home ---------- */
views.home = function (main) {
  var box = null;
  if (unread.length) {
    box = el('div', {class: 'card newbox'}, el('h3', {text: '🔔 تسجيلات جديدة (' + unread.length + ')'}));
    unread.slice().reverse().forEach(function (u) {
      box.appendChild(el('div', {class: 'item', style: 'padding:6px 0;border-top:1px solid var(--line)'},
        el('div', {class: 'top'}, el('span', {class: 'name', text: u.name}), badge(ST_REG, u.status)),
        el('div', {class: 'meta', text: u.event + ' · ' + u.persons + ' شخص · ' + fmt(u.created_at)})));
    });
    box.appendChild(el('div', {style: 'margin-top:10px'}, el('button', {class: 'btn alt', text: 'تمت المشاهدة', onclick: function () { unread = []; saveState(); updateBadge(); go('home'); }})));
  }
  main.appendChild(el('p', {class: 'muted center', text: 'جارٍ التحميل…'}));
  api('stats').then(function (s) {
    clear(main);
    if (box) main.appendChild(box);
    var r = s.registrations || {}, sb = s.subscribers || {};
    main.appendChild(el('h2', {text: 'التسجيلات في الفعاليات'}));
    main.appendChild(el('div', {class: 'grid'},
      stat(r.confirmed || 0, 'مؤكدة (لم تحضر بعد)'), stat(r.checked_in || 0, 'حضرت'),
      stat(s.checked_in_persons || 0, 'أشخاص دخلوا'), stat(r.pending_payment || 0, 'بانتظار الدفع')));
    main.appendChild(el('h2', {text: 'النشرة البريدية'}));
    main.appendChild(el('div', {class: 'grid'},
      stat(sb.confirmed || 0, 'مشترك مؤكد'), stat(sb.pending || 0, 'بانتظار التأكيد'),
      stat(sb.unsubscribed || 0, 'ألغوا الاشتراك'), stat(r.cancelled || 0, 'تسجيلات ملغاة')));
    main.appendChild(el('div', {style: 'margin-top:14px'}, el('button', {class: 'btn alt', text: 'تحديث', onclick: function () { go('home'); }})));
  }).catch(function (e) { if (!failure(e)) { clear(main); main.appendChild(el('div', {class: 'msg', text: 'تعذر التحميل: ' + e.message})); } });
};
function stat(n, label) { return el('div', {class: 'stat'}, el('b', {text: String(n)}), el('span', {text: label})); }

/* ---------- lists (registrations / subscribers) ---------- */
function listView(main, cfg) {
  var state = {page: 1, search: '', status: '', event: '', busy: false};
  var search = el('input', {type: 'search', placeholder: cfg.placeholder});
  var status = el('select', {}, el('option', {value: '', text: 'كل الحالات'}));
  Object.keys(cfg.statuses).forEach(function (k) { status.appendChild(el('option', {value: k, text: cfg.statuses[k][0]})); });
  var evSel = null;
  var filters = el('div', {class: 'row'}, status);
  if (cfg.events) {
    evSel = el('select', {}, el('option', {value: '', text: 'كل الفعاليات'}));
    events.forEach(function (ev) { evSel.appendChild(el('option', {value: ev.id, text: ev.title})); });
    filters = el('div', {}, el('div', {class: 'row'}, status), el('div', {class: 'row'}, evSel));
  }
  var count = el('p', {class: 'muted', text: ''});
  var list = el('div');
  var more = el('button', {class: 'btn alt hide', text: 'تحميل المزيد', onclick: function () { state.page++; load(false); }});
  main.appendChild(el('div', {class: 'row'}, search));
  main.appendChild(filters);
  main.appendChild(count); main.appendChild(list); main.appendChild(more);

  function load(reset) {
    if (state.busy) return;
    state.busy = true;
    if (reset) { state.page = 1; clear(list); }
    api(cfg.path, {params: {page: state.page, per_page: 25, search: state.search, status: state.status, event_id: state.event}}).then(function (d) {
      state.busy = false;
      count.textContent = d.total + ' نتيجة';
      d.items.forEach(function (it) { list.appendChild(cfg.render(it)); });
      if (!d.items.length && reset) list.appendChild(el('div', {class: 'card muted center', text: 'لا توجد نتائج.'}));
      more.classList.toggle('hide', d.page >= d.pages);
    }).catch(function (e) {
      state.busy = false;
      if (!failure(e)) list.appendChild(el('div', {class: 'msg', text: 'تعذر التحميل: ' + e.message}));
    });
  }
  search.addEventListener('input', debounce(function () { state.search = search.value.trim(); load(true); }, 350));
  status.addEventListener('change', function () { state.status = status.value; load(true); });
  if (evSel) evSel.addEventListener('change', function () { state.event = evSel.value; load(true); });
  load(true);
}
function contact(label, href) { return el('a', {href: href, text: label}); }

views.regs = function (main) {
  listView(main, {
    path: 'registrations', placeholder: 'ابحث بالاسم أو البريد أو الهاتف أو رقم التذكرة', statuses: ST_REG, events: true,
    render: function (r) {
      return el('div', {class: 'card item'},
        el('div', {class: 'top'}, el('span', {class: 'name', text: r.name}), badge(ST_REG, r.status)),
        el('div', {class: 'meta', text: r.event}),
        el('div', {class: 'meta'}, r.persons + ' شخص · رقم ' + (r.ticket_number || '—')),
        el('div', {class: 'meta'}, contact(r.email, 'mailto:' + r.email), r.phone ? ' · ' : '', r.phone ? contact(r.phone, 'tel:' + r.phone) : null),
        el('div', {class: 'meta', text: r.checked_in_at ? ('دخل: ' + fmt(r.checked_in_at)) : ('سُجّل: ' + fmt(r.created_at))}));
    }
  });
};
views.subs = function (main) {
  listView(main, {
    path: 'subscribers', placeholder: 'ابحث بالبريد أو الاسم', statuses: ST_SUB,
    render: function (s) {
      return el('div', {class: 'card item'},
        el('div', {class: 'top'}, el('span', {class: 'name', text: s.name || s.email}), badge(ST_SUB, s.status)),
        el('div', {class: 'meta'}, contact(s.email, 'mailto:' + s.email)),
        el('div', {class: 'meta', text: (s.lang ? s.lang.toUpperCase() + ' · ' : '') + fmt(s.created_at)}));
    }
  });
};

/* ---------- account ---------- */
views.me = function (main) {
  main.appendChild(el('div', {class: 'card'},
    el('b', {text: me ? me.name : ''}), el('div', {class: 'muted', text: CFG.site})));
  var snd = el('input', {type: 'checkbox'}); snd.checked = !!prefs.sound;
  snd.addEventListener('change', function () { prefs.sound = snd.checked; saveState(); });
  var ntf = el('input', {type: 'checkbox'}); ntf.checked = !!prefs.notify && ('Notification' in window) && Notification.permission === 'granted';
  var ntfMsg = el('p', {class: 'muted', text: ''});
  ntf.addEventListener('change', function () {
    if (!ntf.checked) { prefs.notify = false; saveState(); return; }
    if (!('Notification' in window)) { ntf.checked = false; ntfMsg.textContent = 'المتصفح لا يدعم الإشعارات.'; return; }
    Notification.requestPermission().then(function (p) {
      prefs.notify = (p === 'granted'); ntf.checked = prefs.notify; saveState();
      ntfMsg.textContent = prefs.notify ? '' : 'لم يُسمح بالإشعارات. فعّلها من إعدادات المتصفح أو التطبيق.';
    });
  });
  main.appendChild(el('div', {class: 'card'},
    el('b', {text: 'تنبيهات التسجيلات الجديدة'}),
    el('label', {class: 'opt'}, snd, ' صوت واهتزاز عند وصول تسجيل جديد'),
    el('label', {class: 'opt'}, ntf, ' إشعار على الهاتف عندما يكون التطبيق في الخلفية'),
    ntfMsg,
    el('p', {class: 'muted', text: 'التطبيق يتحقق من الموقع كل 20 ثانية وهو مفتوح. عند إغلاقه تماماً لا تصل التنبيهات، لذلك يبقى بريد الإشعار في إعدادات الإضافة هو التنبيه الدائم.'})));
  main.appendChild(el('button', {class: 'btn alt', text: 'تسجيل الخروج', onclick: function () { stopPolling(); clearState(); saveAuth(null); me = null; showLogin(''); }}));
  main.appendChild(el('p', {class: 'muted', text: 'لإلغاء وصول هذا الهاتف: احذف «كلمة مرور التطبيق» من ملفك الشخصي في ووردبريس. ولتثبيت التطبيق: من قائمة المتصفح اختر «إضافة إلى الشاشة الرئيسية».'}));
};

/* ---------- scanner ---------- */
var stream = null, scanning = false, raf = 0, video = null, canvas = null, ctx = null;
function stopScan() {
  scanning = false;
  if (raf) cancelAnimationFrame(raf);
  raf = 0;
  if (stream) { stream.getTracks().forEach(function (t) { t.stop(); }); stream = null; }
  if (video) { try { video.srcObject = null; } catch (e) {} }
}
views.scan = function (main) {
  var evSel = el('select', {}, el('option', {value: '', text: 'كل الفعاليات'}));
  events.forEach(function (ev) { evSel.appendChild(el('option', {value: ev.id, text: ev.title})); });
  video = el('video', {id: 'video', playsinline: true, muted: true});
  canvas = document.createElement('canvas');
  ctx = canvas.getContext('2d', {willReadFrequently: true});
  var vwrap = el('div', {class: 'vwrap'}, video);
  var note = el('p', {class: 'muted center', text: ''});
  var result = el('div');
  var manual = el('input', {type: 'text', placeholder: 'أو اكتب رقم/رمز التذكرة', autocapitalize: 'off'});
  var startBtn = el('button', {class: 'btn', text: 'تشغيل الكاميرا', onclick: start});

  main.appendChild(el('div', {class: 'row'}, evSel));
  main.appendChild(vwrap); main.appendChild(note); main.appendChild(startBtn); main.appendChild(result);
  main.appendChild(el('h2', {text: 'إدخال يدوي'}));
  main.appendChild(el('div', {class: 'row'}, manual, el('button', {class: 'btn', style: 'flex:0 0 90px', text: 'بحث', onclick: function () { if (manual.value.trim()) lookup(manual.value.trim()); }})));

  function start() {
    clear(result);
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) { note.textContent = 'المتصفح لا يدعم الكاميرا. استخدم الإدخال اليدوي.'; return; }
    if (typeof jsQR !== 'function') { note.textContent = 'تعذر تحميل أداة قراءة QR.'; return; }
    navigator.mediaDevices.getUserMedia({video: {facingMode: {ideal: 'environment'}}, audio: false}).then(function (s) {
      stream = s; video.srcObject = s;
      return video.play();
    }).then(function () {
      scanning = true; note.textContent = 'وجّه الكاميرا نحو رمز QR في التذكرة'; startBtn.classList.add('hide'); vwrap.classList.remove('hide'); tick();
    }).catch(function () { note.textContent = 'تعذر تشغيل الكاميرا. اسمح بالوصول للكاميرا من إعدادات المتصفح، أو استخدم الإدخال اليدوي.'; });
  }
  function tick() {
    if (!scanning) return;
    if (video.readyState === video.HAVE_ENOUGH_DATA && video.videoWidth) {
      var scale = Math.min(1, 640 / video.videoWidth);
      var w = Math.round(video.videoWidth * scale), h = Math.round(video.videoHeight * scale);
      canvas.width = w; canvas.height = h;
      ctx.drawImage(video, 0, 0, w, h);
      var img = ctx.getImageData(0, 0, w, h);
      var code = jsQR(img.data, w, h, {inversionAttempts: 'dontInvert'});
      if (code && code.data) { stopScan(); if (navigator.vibrate) navigator.vibrate(60); lookup(code.data); return; }
    }
    raf = requestAnimationFrame(tick);
  }
  function lookup(value) {
    clear(result); note.textContent = 'جارٍ التحقق…';
    api('checkin/lookup', {method: 'POST', body: {code: value, event_id: evSel.value || 0}}).then(function (d) {
      note.textContent = '';
      showResult(d);
    }).catch(function (e) { if (!failure(e)) { note.textContent = ''; result.appendChild(el('div', {class: 'msg', text: 'تعذر التحقق: ' + e.message})); result.appendChild(again()); } });
  }
  function again() {
    return el('button', {class: 'btn', text: 'مسح التالي', onclick: function () { clear(result); manual.value = ''; start(); }});
  }
  function showResult(d) {
    var r = d.registration, kind = 'bad', title = '', lines = [];
    if (r) { lines = [el('div', {class: 'info'}, el('b', {text: r.name}), ' · ' + r.persons + ' شخص'), el('div', {class: 'info', text: r.event}), el('div', {class: 'info', text: 'رقم التذكرة: ' + (r.ticket_number || '—')})]; }
    switch (d.result) {
      case 'valid': kind = 'ok'; title = '✅ تذكرة صالحة'; break;
      case 'already_used': kind = 'warn'; title = '⚠️ التذكرة مستخدمة سابقاً'; if (r && r.checked_in_at) lines.push(el('div', {class: 'info', text: 'دخلت: ' + fmt(r.checked_in_at)})); break;
      case 'pending_payment': kind = 'warn'; title = '⚠️ لم يتم الدفع بعد'; break;
      case 'cancelled': title = '⛔ تسجيل ملغى'; break;
      case 'wrong_event': title = '⛔ التذكرة لفعالية أخرى'; break;
      default: title = '⛔ تذكرة غير موجودة';
    }
    var box = el('div', {class: 'res ' + kind}, el('h3', {text: title}));
    lines.forEach(function (l) { box.appendChild(l); });
    result.appendChild(box);
    if (d.result === 'valid') {
      var n = r.persons;
      var num = el('b', {text: String(n)});
      var stepper = r.persons > 1 ? el('div', {class: 'stepper'},
        el('button', {text: '+', onclick: function () { if (n < r.persons) { n++; num.textContent = n; } }}), num,
        el('button', {text: '−', onclick: function () { if (n > 1) { n--; num.textContent = n; } }})) : null;
      if (stepper) result.appendChild(el('p', {class: 'center muted', text: 'عدد الأشخاص الداخلين'}));
      if (stepper) result.appendChild(stepper);
      var ok = el('button', {class: 'btn', text: 'تأكيد الدخول', onclick: function () {
        ok.disabled = true;
        api('checkin/confirm', {method: 'POST', body: {id: r.id, persons: n}}).then(function () {
          clear(result);
          result.appendChild(el('div', {class: 'res ok'}, el('h3', {text: '✅ تم تسجيل الدخول'}), el('div', {class: 'info', text: r.name + ' · ' + n + ' شخص'})));
          result.appendChild(again());
        }).catch(function (e) {
          if (failure(e)) return;
          clear(result);
          result.appendChild(el('div', {class: 'msg', text: e.status === 409 ? 'لم يتم التسجيل: التذكرة استُخدمت للتو أو لم تعد صالحة.' : ('خطأ: ' + e.message)}));
          result.appendChild(again());
        });
      }});
      result.appendChild(ok);
      result.appendChild(el('div', {style: 'height:8px'}));
    }
    result.appendChild(again());
  }
};

/* ---------- boot ---------- */
function boot() {
  shell();
  api('events').then(function (e) { events = e || []; }).catch(function () { events = []; }).then(function () { go(tab); updateBadge(); startPolling(); });
}
function init() {
  if ('serviceWorker' in navigator) {
    try { navigator.serviceWorker.register(CFG.sw, {scope: new URL(CFG.scope).pathname}).catch(function () {}); } catch (e) {}
  }
  loadAuth();
  loadState();
  if (!auth) { showLogin(''); return; }
  api('me').then(function (m) { me = m; boot(); }).catch(function (e) {
    if (e && e.auth) { saveAuth(null); showLogin('انتهت الجلسة. سجّل الدخول من جديد.'); }
    else { showLogin('تعذر الاتصال بالموقع. تحقق من الإنترنت ثم أعد المحاولة.'); }
  });
}
init();
})();
</script>
</body>
</html>
