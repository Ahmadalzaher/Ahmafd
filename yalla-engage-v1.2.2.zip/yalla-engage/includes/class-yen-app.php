<?php
/**
 * Serves the Yalla Engage mobile web app (installable PWA).
 *
 * Open  https://your-site/?yena_app=1  on a phone and use "Add to Home screen".
 *
 * @package Yalla_Engage
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class YENA_App {

	public static function init() {
		add_action( 'init', array( __CLASS__, 'maybe_serve' ), 1 );
	}

	public static function app_url() {
		return add_query_arg( 'yena_app', '1', home_url( '/' ) );
	}

	public static function maybe_serve() {
		if ( ! isset( $_GET['yena_app'] ) ) {
			return;
		}
		$what = sanitize_key( wp_unslash( $_GET['yena_app'] ) );

		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}
		nocache_headers();

		if ( 'manifest' === $what ) {
			header( 'Content-Type: application/manifest+json; charset=utf-8' );
			echo wp_json_encode( array(
				'name'             => 'Yalla Engage',
				'short_name'       => 'Yalla',
				'start_url'        => self::app_url(),
				'scope'            => home_url( '/' ),
				'display'          => 'standalone',
				'orientation'      => 'portrait',
				'dir'              => 'rtl',
				'lang'             => 'ar',
				'background_color' => '#12332c',
				'theme_color'      => '#12332c',
				'icons'            => array(
					array( 'src' => YENA_URI . 'assets/images/app-icon-192.png', 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'any maskable' ),
					array( 'src' => YENA_URI . 'assets/images/app-icon-512.png', 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'any maskable' ),
				),
			), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
			exit;
		}

		if ( 'sw' === $what ) {
			header( 'Content-Type: application/javascript; charset=utf-8' );
			header( 'Service-Worker-Allowed: ' . wp_parse_url( home_url( '/' ), PHP_URL_PATH ) );
			// Minimal worker: makes the app installable; never caches API data.
			echo "self.addEventListener('install',function(){self.skipWaiting();});\n";
			echo "self.addEventListener('activate',function(e){e.waitUntil(self.clients.claim());});\n";
			echo "self.addEventListener('fetch',function(){});\n";
			echo "self.addEventListener('notificationclick',function(e){e.notification.close();var u=(e.notification.data&&e.notification.data.url)||'/';e.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(function(l){for(var i=0;i<l.length;i++){if('focus' in l[i]){return l[i].focus();}}return self.clients.openWindow(u);}));});\n";
			exit;
		}

		if ( '1' !== $what ) {
			return;
		}

		$app = array(
			'api'      => esc_url_raw( rest_url( YENA_REST::NS . '/' ) ),
			'manifest' => esc_url( add_query_arg( 'yena_app', 'manifest', home_url( '/' ) ) ),
			'sw'       => esc_url_raw( add_query_arg( 'yena_app', 'sw', home_url( '/' ) ) ),
			'scope'    => esc_url_raw( home_url( '/' ) ),
			'jsqr'     => esc_url( YENA_URI . 'assets/js/jsqr.js' ),
			'icon'     => esc_url( YENA_URI . 'assets/images/app-icon-192.png' ),
			'profile'  => esc_url( admin_url( 'profile.php#application-passwords-section' ) ),
			'start'    => esc_url_raw( self::app_url() ),
			'site'     => get_bloginfo( 'name' ),
		);

		header( 'Content-Type: text/html; charset=utf-8' );
		header( 'X-Robots-Tag: noindex, nofollow' );
		include YENA_DIR . 'templates/app.php';
		exit;
	}
}
