<?php
/**
 * REST API used by the Yalla Engage mobile app.
 *
 * Authentication: WordPress Application Passwords (sent in the X-Yena-Auth
 * header as base64("username:application-password") so hosts that strip the standard
 * Authorization header still work). Only users with the "yena_manage"
 * capability can use the API.
 *
 * @package Yalla_Engage
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class YENA_REST {

	const NS = 'yalla-engage/v1';

	/** Why the last header login failed (shown to the app so the cause is clear). */
	private static $reason = '';

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
		self::register_auth();
	}

	/**
	 * Register the header login as early as possible (called when the plugin file
	 * loads), so it also works if another plugin resolves the current user
	 * before plugins_loaded.
	 */
	public static function register_auth() {
		add_filter( 'determine_current_user', array( __CLASS__, 'header_auth' ), 30 );
	}

	/**
	 * Log a user in from the X-Yena-Auth header, for this plugin's routes only.
	 */
	public static function header_auth( $user_id ) {
		if ( $user_id || empty( $_SERVER['HTTP_X_YENA_AUTH'] ) ) {
			return $user_id;
		}
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		$route = isset( $_GET['rest_route'] ) ? (string) wp_unslash( $_GET['rest_route'] ) : '';
		if ( false === strpos( $uri . $route, self::NS ) ) {
			return $user_id;
		}
		if ( ! function_exists( 'wp_authenticate_application_password' ) || ! function_exists( 'wp_is_application_passwords_available' ) ) {
			self::$reason = 'unsupported';
			return $user_id;
		}

		$ip       = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '0';
		$fail_key = 'yena_authfail_' . md5( $ip );
		if ( (int) get_transient( $fail_key ) >= 10 ) {
			self::$reason = 'throttled';
			return $user_id; // Too many failed logins from this address; try again later.
		}

		// Header value is base64( username:application-password ) so non-Latin usernames are safe.
		$raw = base64_decode( (string) wp_unslash( $_SERVER['HTTP_X_YENA_AUTH'] ), true );
		$parts = false === $raw ? array() : explode( ':', $raw, 2 );
		if ( 2 !== count( $parts ) || '' === $parts[0] || '' === $parts[1] ) {
			self::$reason = 'bad_format';
			return $user_id;
		}
		if ( ! wp_is_application_passwords_available() ) {
			self::$reason = 'app_passwords_disabled';
			return $user_id;
		}

		add_filter( 'application_password_is_api_request', '__return_true' );
		$user = wp_authenticate_application_password( null, trim( $parts[0] ), $parts[1] );
		remove_filter( 'application_password_is_api_request', '__return_true' );

		if ( $user instanceof WP_User ) {
			delete_transient( $fail_key );
			return (int) $user->ID;
		}

		self::$reason = ( $user instanceof WP_Error && 'application_passwords_disabled_for_user' === $user->get_error_code() ) ? 'app_passwords_disabled' : 'bad_credentials';
		set_transient( $fail_key, (int) get_transient( $fail_key ) + 1, 15 * MINUTE_IN_SECONDS );
		return $user_id;
	}

	public static function can_manage() {
		if ( is_user_logged_in() && current_user_can( 'yena_manage' ) ) {
			return true;
		}
		if ( is_user_logged_in() ) {
			$reason = 'no_capability';
		} elseif ( self::$reason ) {
			$reason = self::$reason;
		} elseif ( empty( $_SERVER['HTTP_X_YENA_AUTH'] ) && empty( $_SERVER['HTTP_AUTHORIZATION'] ) ) {
			$reason = 'header_missing';
		} else {
			$reason = 'bad_credentials';
		}
		return new WP_Error( 'yena_forbidden', 'Unauthorized', array( 'status' => 401, 'reason' => $reason ) );
	}

	public static function register_routes() {
		$perm = array( __CLASS__, 'can_manage' );

		register_rest_route( self::NS, '/me', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'me' ),
			'permission_callback' => $perm,
		) );
		register_rest_route( self::NS, '/stats', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'stats' ),
			'permission_callback' => $perm,
		) );
		register_rest_route( self::NS, '/events', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'events' ),
			'permission_callback' => $perm,
		) );
		register_rest_route( self::NS, '/registrations', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'registrations' ),
			'permission_callback' => $perm,
		) );
		register_rest_route( self::NS, '/registrations/feed', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'feed' ),
			'permission_callback' => $perm,
		) );
		register_rest_route( self::NS, '/subscribers', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'subscribers' ),
			'permission_callback' => $perm,
		) );
		register_rest_route( self::NS, '/checkin/lookup', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'checkin_lookup' ),
			'permission_callback' => $perm,
		) );
		register_rest_route( self::NS, '/checkin/confirm', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'checkin_confirm' ),
			'permission_callback' => $perm,
		) );
	}

	/* ------------------------------------------------------------------ */

	public static function me() {
		$user = wp_get_current_user();
		return array(
			'name' => $user->display_name,
			'site' => get_bloginfo( 'name' ),
		);
	}

	public static function stats() {
		global $wpdb;
		$subs = YENA_DB::subscribers();
		$regs = YENA_DB::registrations();

		$sub_rows = $wpdb->get_results( "SELECT status, COUNT(*) AS c FROM {$subs} GROUP BY status" ); // phpcs:ignore
		$reg_rows = $wpdb->get_results( "SELECT status, COUNT(*) AS c, COALESCE(SUM(persons),0) AS p FROM {$regs} GROUP BY status" ); // phpcs:ignore

		$subscribers = array( 'confirmed' => 0, 'pending' => 0, 'unsubscribed' => 0 );
		foreach ( (array) $sub_rows as $row ) {
			$subscribers[ $row->status ] = (int) $row->c;
		}
		$registrations = array();
		$persons       = array();
		foreach ( (array) $reg_rows as $row ) {
			$registrations[ $row->status ] = (int) $row->c;
			$persons[ $row->status ]       = (int) $row->p;
		}
		$checked_in_persons = (int) $wpdb->get_var( "SELECT COALESCE(SUM(checked_in_persons),0) FROM {$regs} WHERE status = 'checked_in'" ); // phpcs:ignore

		return array(
			'subscribers'        => $subscribers,
			'registrations'      => $registrations,
			'persons'            => $persons,
			'checked_in_persons' => $checked_in_persons,
		);
	}

	public static function events() {
		$posts = get_posts( array(
			'post_type'      => 'yd_event',
			'post_status'    => 'publish',
			'posts_per_page' => 200,
			'orderby'        => 'date',
			'order'          => 'DESC',
		) );
		$out = array();
		foreach ( $posts as $p ) {
			$out[] = array( 'id' => (int) $p->ID, 'title' => wp_strip_all_tags( get_the_title( $p ) ) );
		}
		return $out;
	}

	private static function paging( WP_REST_Request $req ) {
		$per_page = max( 1, min( 50, (int) $req->get_param( 'per_page' ) ?: 25 ) );
		$page     = max( 1, (int) $req->get_param( 'page' ) );
		return array( $per_page, $page, ( $page - 1 ) * $per_page );
	}

	public static function registrations( WP_REST_Request $req ) {
		global $wpdb;
		$table = YENA_DB::registrations();
		list( $per_page, $page, $offset ) = self::paging( $req );

		$where  = array( '1=1' );
		$args   = array();
		$search = trim( (string) $req->get_param( 'search' ) );
		if ( '' !== $search ) {
			$like    = '%' . $wpdb->esc_like( $search ) . '%';
			$where[] = '(name LIKE %s OR email LIKE %s OR phone LIKE %s OR ticket_number LIKE %s)';
			array_push( $args, $like, $like, $like, $like );
		}
		$status = sanitize_key( (string) $req->get_param( 'status' ) );
		if ( in_array( $status, array( 'confirmed', 'pending_payment', 'checked_in', 'cancelled', 'refunded' ), true ) ) {
			$where[] = 'status = %s';
			$args[]  = $status;
		}
		$event_id = absint( $req->get_param( 'event_id' ) );
		if ( $event_id ) {
			$where[] = 'event_id = %d';
			$args[]  = $event_id;
		}
		$sql_where = implode( ' AND ', $where );

		$count_sql = "SELECT COUNT(*) FROM {$table} WHERE {$sql_where}"; // phpcs:ignore
		$total     = (int) $wpdb->get_var( $args ? $wpdb->prepare( $count_sql, $args ) : $count_sql ); // phpcs:ignore

		$list_sql = "SELECT id, event_id, name, email, phone, persons, status, payment_status, ticket_number, created_at, checked_in_at, checked_in_persons FROM {$table} WHERE {$sql_where} ORDER BY id DESC LIMIT %d OFFSET %d"; // phpcs:ignore
		$rows     = $wpdb->get_results( $wpdb->prepare( $list_sql, array_merge( $args, array( $per_page, $offset ) ) ) ); // phpcs:ignore

		$titles = array();
		$items  = array();
		foreach ( (array) $rows as $row ) {
			$eid = (int) $row->event_id;
			if ( ! isset( $titles[ $eid ] ) ) {
				$titles[ $eid ] = wp_strip_all_tags( get_the_title( $eid ) );
			}
			$items[] = array(
				'id'             => (int) $row->id,
				'event_id'       => $eid,
				'event'          => $titles[ $eid ],
				'name'           => $row->name,
				'email'          => $row->email,
				'phone'          => $row->phone,
				'persons'        => (int) $row->persons,
				'status'         => $row->status,
				'payment_status' => $row->payment_status,
				'ticket_number'  => $row->ticket_number,
				'created_at'     => $row->created_at,
				'checked_in_at'  => $row->checked_in_at,
				'checked_in_persons' => null === $row->checked_in_persons ? null : (int) $row->checked_in_persons,
			);
		}

		return array(
			'items' => $items,
			'total' => $total,
			'page'  => $page,
			'pages' => max( 1, (int) ceil( $total / $per_page ) ),
		);
	}

	/**
	 * New registrations since a cursor (the highest registration id already seen).
	 * Without a cursor it only returns the current cursor, so a fresh install of
	 * the app does not flood the user with old registrations.
	 */
	public static function feed( WP_REST_Request $req ) {
		global $wpdb;
		$table  = YENA_DB::registrations();
		$latest = (int) $wpdb->get_var( "SELECT COALESCE(MAX(id),0) FROM {$table}" ); // phpcs:ignore
		$after  = absint( $req->get_param( 'after_id' ) );

		$items  = array();
		$cursor = $latest;
		if ( $after > 0 && $latest > $after ) {
			$rows   = $wpdb->get_results( $wpdb->prepare( "SELECT id, event_id, name, persons, status, created_at FROM {$table} WHERE id > %d ORDER BY id ASC LIMIT 50", $after ) ); // phpcs:ignore
			$titles = array();
			foreach ( (array) $rows as $row ) {
				$eid = (int) $row->event_id;
				if ( ! isset( $titles[ $eid ] ) ) {
					$titles[ $eid ] = wp_strip_all_tags( get_the_title( $eid ) );
				}
				$items[] = array(
					'id'         => (int) $row->id,
					'event'      => $titles[ $eid ],
					'name'       => $row->name,
					'persons'    => (int) $row->persons,
					'status'     => $row->status,
					'created_at' => $row->created_at,
				);
				$cursor = (int) $row->id; // Continue from the last item if there were more than 50.
			}
		} elseif ( $after > $latest ) {
			$cursor = $latest; // Registrations were deleted; resync.
		}

		nocache_headers();
		return array( 'cursor' => $cursor, 'latest_id' => $latest, 'items' => $items );
	}

	public static function subscribers( WP_REST_Request $req ) {
		global $wpdb;
		$table = YENA_DB::subscribers();
		list( $per_page, $page, $offset ) = self::paging( $req );

		$where  = array( '1=1' );
		$args   = array();
		$search = trim( (string) $req->get_param( 'search' ) );
		if ( '' !== $search ) {
			$like    = '%' . $wpdb->esc_like( $search ) . '%';
			$where[] = '(email LIKE %s OR name LIKE %s)';
			array_push( $args, $like, $like );
		}
		$status = sanitize_key( (string) $req->get_param( 'status' ) );
		if ( in_array( $status, array( 'confirmed', 'pending', 'unsubscribed' ), true ) ) {
			$where[] = 'status = %s';
			$args[]  = $status;
		}
		$sql_where = implode( ' AND ', $where );

		$count_sql = "SELECT COUNT(*) FROM {$table} WHERE {$sql_where}"; // phpcs:ignore
		$total     = (int) $wpdb->get_var( $args ? $wpdb->prepare( $count_sql, $args ) : $count_sql ); // phpcs:ignore

		$list_sql = "SELECT id, email, name, lang, status, created_at, confirmed_at FROM {$table} WHERE {$sql_where} ORDER BY id DESC LIMIT %d OFFSET %d"; // phpcs:ignore
		$rows     = $wpdb->get_results( $wpdb->prepare( $list_sql, array_merge( $args, array( $per_page, $offset ) ) ) ); // phpcs:ignore

		$items = array();
		foreach ( (array) $rows as $row ) {
			$items[] = array(
				'id'           => (int) $row->id,
				'email'        => $row->email,
				'name'         => $row->name,
				'lang'         => $row->lang,
				'status'       => $row->status,
				'created_at'   => $row->created_at,
				'confirmed_at' => $row->confirmed_at,
			);
		}

		return array(
			'items' => $items,
			'total' => $total,
			'page'  => $page,
			'pages' => max( 1, (int) ceil( $total / $per_page ) ),
		);
	}

	/* ------------------------------ check-in --------------------------- */

	/** Accept a ticket URL (QR content), a ticket code or a ticket number. */
	private static function normalise_code( $value ) {
		$value = trim( (string) $value );
		if ( preg_match( '/[?&]code=([^&#\s]+)/', $value, $m ) ) {
			$value = urldecode( $m[1] );
		}
		return substr( sanitize_text_field( $value ), 0, 128 );
	}

	private static function registration_view( $row ) {
		return array(
			'id'            => (int) $row->id,
			'name'          => $row->name,
			'persons'       => (int) $row->persons,
			'event_id'      => (int) $row->event_id,
			'event'         => wp_strip_all_tags( get_the_title( (int) $row->event_id ) ),
			'ticket_number' => $row->ticket_number,
			'status'        => $row->status,
			'checked_in_at' => $row->checked_in_at,
		);
	}

	public static function checkin_lookup( WP_REST_Request $req ) {
		global $wpdb;
		$table    = YENA_DB::registrations();
		$code     = self::normalise_code( $req->get_param( 'code' ) );
		$event_id = absint( $req->get_param( 'event_id' ) );

		$row = null;
		if ( '' !== $code ) {
			$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE ticket_code = %s OR ticket_number = %s ORDER BY id DESC LIMIT 1", $code, $code ) ); // phpcs:ignore
		}

		if ( ! $row ) {
			$result = 'not_found';
		} elseif ( $event_id && (int) $row->event_id !== $event_id ) {
			$result = 'wrong_event';
		} elseif ( 'cancelled' === $row->status || 'refunded' === $row->status ) {
			$result = 'cancelled';
		} elseif ( 'checked_in' === $row->status ) {
			$result = 'already_used';
		} elseif ( 'pending_payment' === $row->status ) {
			$result = 'pending_payment';
		} else {
			$result = 'valid';
		}

		return array(
			'result'       => $result,
			'registration' => $row ? self::registration_view( $row ) : null,
		);
	}

	public static function checkin_confirm( WP_REST_Request $req ) {
		global $wpdb;
		$table   = YENA_DB::registrations();
		$reg_id  = absint( $req->get_param( 'id' ) );
		$persons = max( 1, absint( $req->get_param( 'persons' ) ) );

		$row = $reg_id ? $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $reg_id ) ) : null; // phpcs:ignore
		if ( ! $row || 'confirmed' !== $row->status ) {
			return new WP_Error( 'yena_invalid', 'invalid', array( 'status' => 409 ) );
		}
		$persons = max( 1, min( (int) $row->persons, $persons ) );

		// Atomic: only the first confirmation of a ticket can succeed.
		$updated = $wpdb->update(
			$table,
			array(
				'status'             => 'checked_in',
				'checked_in_at'      => current_time( 'mysql', true ),
				'checked_in_by'      => get_current_user_id(),
				'checked_in_persons' => $persons,
			),
			array( 'id' => $reg_id, 'status' => 'confirmed' ),
			array( '%s', '%s', '%d', '%d' ),
			array( '%d', '%s' )
		);
		if ( 1 !== (int) $updated ) {
			return new WP_Error( 'yena_invalid', 'already_used', array( 'status' => 409 ) );
		}

		return array( 'ok' => true, 'persons' => $persons );
	}
}
