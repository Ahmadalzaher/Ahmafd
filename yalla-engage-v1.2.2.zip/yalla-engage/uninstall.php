<?php
/**
 * Uninstall script for Yalla Engage.
 *
 * WordPress runs this file non-interactively when the plugin is deleted, so it
 * must not print anything. Data is removed only if the administrator enabled
 * "delete all data on uninstall" in the plugin settings (default: keep data).
 *
 * @package Yalla_Engage
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

wp_clear_scheduled_hook( 'yena_process_queue' );
wp_clear_scheduled_hook( 'yena_send_reminders' );
wp_clear_scheduled_hook( 'yena_cleanup_pending_payments' );

$settings = get_option( 'yena_settings', array() );
if ( empty( $settings['delete_on_uninstall'] ) || '1' !== $settings['delete_on_uninstall'] ) {
	return;
}

$tables = array(
	$wpdb->prefix . 'yena_subscribers',
	$wpdb->prefix . 'yena_campaigns',
	$wpdb->prefix . 'yena_queue',
	$wpdb->prefix . 'yena_registrations',
);
foreach ( $tables as $table ) {
	$wpdb->query( "DROP TABLE IF EXISTS {$table}" ); // phpcs:ignore
}

delete_option( 'yena_settings' );
delete_option( 'yena_db_version' );
delete_option( 'yena_install_pending' );
delete_option( 'yena_install_error' );

remove_role( 'yena_manager' );
foreach ( array( 'administrator', 'editor' ) as $role_name ) {
	$role = get_role( $role_name );
	if ( $role ) {
		$role->remove_cap( 'yena_manage' );
	}
}
