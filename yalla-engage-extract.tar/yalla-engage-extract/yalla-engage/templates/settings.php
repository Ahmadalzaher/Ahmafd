<?php
/**
 * Settings template for Yalla Engage.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$settings = isset( $settings ) ? $settings : array();
$notify_email = isset( $settings['notify_email'] ) ? $settings['notify_email'] : get_option( 'admin_email' );
$batch_size   = isset( $settings['batch_size'] ) ? $settings['batch_size'] : 20;
$reminder     = isset( $settings['reminder'] ) ? $settings['reminder'] : '1';
$texts        = isset( $settings['texts'] ) ? $settings['texts'] : array();

// Saved notice.
$saved = isset( $_GET['yena-saved'] ) ? '1' : '';
if ( $saved ) {
	echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'تم حفظ الإعدادات بنجاح.', 'yalla-engage' ) . '</p></div>';
}
?>
<div class="wrap">
	<h1><?php echo esc_html__( 'الإعدادات — النشرة والتسجيل', 'yalla-engage' ); ?></h1>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php?action=yena_save_settings' ) ); ?>">
		<?php wp_nonce_field( 'yena_settings' ); ?>

		<h2><?php echo esc_html__( 'البريد والإرسال', 'yalla-engage' ); ?></h2>
		<table class="form-table">
			<tr>
				<th scope="row"><?php echo esc_html__( 'بريد الإشعار للمسؤول', 'yalla-engage' ); ?></th>
				<td><input type="email" name="yena_notify_email" value="<?php echo esc_attr( $notify_email ); ?>" class="regular-text" /> <?php echo esc_html__( 'يصل إليك إشعار عند كل تسجيل جديد.', 'yalla-engage' ); ?></td>
			</tr>
			<tr>
				<th scope="row"><?php echo esc_html__( 'حجم الدفعة للإرسال', 'yalla-engage' ); ?></th>
				<td><input type="number" name="yena_batch_size" value="<?php echo esc_attr( $batch_size ); ?>" min="1" max="100" class="small-text" /> رسائل كل 5 دقائق. اختر قيمة منخفضة لاستضافة مشتركة (مثل 20).</td>
			</tr>
			<tr>
				<th scope="row"><?php echo esc_html__( 'تذكير قبل الفعالية بيوم', 'yalla-engage' ); ?></th>
				<td><input type="checkbox" name="yena_reminder" value="1" <?php checked( $reminder, '1' ); ?> /> <?php echo esc_html__( 'مفعل', 'yalla-engage' ); ?></td>
			</tr>
		</table>

		<h2><?php echo esc_html__( 'نصوص الرسائل والنماذج', 'yalla-engage' ); ?></h2>
		<p><?php echo esc_html__( 'يمكنك تعديل كل نص بكل لغة. القيم الافتراضية تُستخدم إذا ترك الحقل فارغاً.', 'yalla-engage' ); ?></p>

		<?php foreach ( array( 'de' => 'Deutsch', 'en' => 'English', 'ar' => 'العربية' ) as $lang => $lang_name ) : ?>
			<h3><?php echo esc_html( $lang_name ); ?></h3>
			<table class="form-table">
				<?php
				$fields = array(
					'news_confirm_subject' => 'موضوع تأكيد الاشتراك',
					'news_confirm_body'    => 'نص تأكيد الاشتراك',
					'news_welcome_subject' => 'موضوع رسالة الترحيب',
					'news_welcome_body'    => 'نص رسالة الترحيب',
					'reg_confirm_subject'  => 'موضوع تأكيد التسجيل',
					'reg_confirm_body'     => 'نص تأكيد التسجيل',
					'reg_admin_subject'    => 'موضوع إشعار المسؤول',
				);
				foreach ( $fields as $key => $label ) :
					$current = isset( $texts[ $lang ][ $key ] ) ? $texts[ $lang ][ $key ] : '';
				?>
				<tr>
					<th scope="row"><?php echo esc_html( $label ); ?></th>
					<td><textarea name="yena_text_<?php echo esc_attr( $lang ); ?>_<?php echo esc_attr( $key ); ?>" rows="3" class="large-text"><?php echo esc_html( $current ); ?></textarea></td>
				</tr>
			<?php endforeach; ?>
				<!-- Poster image meta box texts -->
				<tr>
					<th scope="row"><?php echo esc_html__( 'عنوان صورة البوستر', 'yalla-engage' ); ?></th>
					<td><textarea name="yena_text_<?php echo esc_attr( $lang ); ?>_poster_title" rows="1" class="large-text"><?php echo esc_html( isset( $texts[ $lang ][ 'poster_title' ] ) ? $texts[ $lang ][ 'poster_title' ] : '' ); ?></textarea></td>
				</tr>
				<tr>
					<th scope="row"><?php echo esc_html__( 'زر تحميل الصورة', 'yalla-engage' ); ?></th>
					<td><textarea name="yena_text_<?php echo esc_attr( $lang ); ?>_poster_upload" rows="1" class="large-text"><?php echo esc_html( isset( $texts[ $lang ][ 'poster_upload' ] ) ? $texts[ $lang ][ 'poster_upload' ] : '' ); ?></textarea></td>
				</tr>
			</table>
		<?php endforeach; ?>

		<h2><?php echo esc_html__( 'مهمة cron المجدولة (Hostinger)', 'yalla-engage' ); ?></h2>
		<p><?php echo esc_html__( 'إذا كانت visitas إلى موقعك قليلة، قد لا يعمل wp-cron بشكل موثوق. أضف مهمة cron الحقيقية في لوحة Hostinger hPanel:', 'yalla-engage' ); ?></p>
		<code style="display:block;background:#f5f1ea;padding:1rem;border:1px solid #ddd;border-radius:4px;margin-bottom:1rem;">
wget -q -O - "https://arab-kulturfestival.de/wp-cron.php?doing_wp_cron=1" &gt;/dev/null 2&gt;&amp;1
		</code>
		<p><?php echo esc_html__( 'ضبط التكرار: كل 5 دقائق.', 'yalla-engage' ); ?></p>

		<?php submit_button( __( 'حفظ الإعدادات', 'yalla-engage' ), 'primary', 'yena_save_settings' ); ?>
	</form>
</div>
