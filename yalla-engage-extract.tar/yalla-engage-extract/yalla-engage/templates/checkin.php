<?php
/**
 * Check-in page for event registration (entrance verification).
 * Mobile-friendly, manager-only page with QR scanner and manual entry.
 *
 * @package Yalla_Engage
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

nocache_headers();

if ( ! current_user_can( 'yena_manage' ) ) {
	wp_die( esc_html__( 'هذه الصفحة تتطلب تسجيل الدخول وصلاحية "مدير النشرة والتسجيل".', 'yalla-engage' ) );
}