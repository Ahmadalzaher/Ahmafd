<?php
/**
 * Campaigns list template.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$rows = isset( $rows ) ? $rows : array();
?>
<div class="wrap">
	<h1><?php echo esc_html__( 'النشرات والحملات', 'yalla-engage' ); ?></h1>

	<table class="wp-list-table widefixed fixed striped">
		<thead>
			<tr>
				<th><?php echo esc_html__( 'الموضوع', 'yalla-engage' ); ?></th>
				<th><?php echo esc_html__( 'اللغة المستهدفة', 'yalla-engage' ); ?></th>
				<th><?php echo esc_html__( 'الحالة', 'yalla-engage' ); ?></th>
				<th><?php echo esc_html__( 'إجمالي', 'yalla-engage' ); ?></th>
				<th><?php echo esc_html__( 'أُرسِل', 'yalla-engage' ); ?></th>
				<th><?php echo esc_html__( 'فشل', 'yalla-engage' ); ?></th>
				<th><?php echo esc_html__( 'تاريخ الإنشاء', 'yalla-engage' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ( $rows as $row ) : ?>
				<tr>
					<td><?php echo esc_html( $row->subject ); ?></td>
					<td><?php echo strtoupper( esc_html( $row->lang_target ) ); ?></td>
					<td><?php echo esc_html( $row->status ); ?></td>
					<td><?php echo (int) $row->total; ?></td>
					<td><?php echo (int) $row->sent; ?></td>
					<td><?php echo (int) $row->failed; ?></td>
					<td><?php echo esc_html( $row->created_at ); ?></td>
				</tr>
			<?php endforeach; ?>
			<?php if ( empty( $rows ) ) : ?>
				<tr><td colspan="7"><?php echo esc_html__( 'لا توجد حملات بعد.', 'yalla-engage' ); ?></td></tr>
			<?php endif; ?>
		</tbody>
	</table>
</div>
