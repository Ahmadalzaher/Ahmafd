<?php
/**
 * Minimal, dependency-free PDF generator for Yalla Engage entry tickets.
 *
 * The QR code is drawn as vector rectangles, so no image library is required
 * and the code stays sharp at any print size.
 *
 * @package Yalla_Engage
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PDF generator for event tickets.
 */
class YENA_PDF {

	/**
	 * Generate a ticket PDF file.
	 *
	 * @param int    $reg_id      Registration ID.
	 * @param string $name        Registrant name.
	 * @param string $event_title Event title.
	 * @param string $date        Event date.
	 * @param string $time        Event time.
	 * @param string $venue       Event venue.
	 * @param int    $persons     Number of persons.
	 * @param string $ticket_num  Ticket number.
	 * @param string $cancel_link Cancellation link (informational only).
	 * @param string $verify_link Link encoded into the QR code.
	 * @param string $qr_file     Unused, kept for backwards compatibility.
	 * @param string $lang        Language code (de/en/ar).
	 * @param string $output      Output PDF file path.
	 * @return bool True on success.
	 */
	public static function generate( $reg_id, $name, $event_title, $date, $time, $venue, $persons, $ticket_num, $cancel_link, $verify_link, $qr_file, $lang, $output ) {
		$pdf = new self();
		return $pdf->build( $name, $event_title, $date, $time, $venue, $persons, $ticket_num, $verify_link, $lang, $output );
	}

	/**
	 * Build the PDF document.
	 *
	 * @return bool
	 */
	private function build( $name, $event_title, $date, $time, $venue, $persons, $ticket_num, $verify_link, $lang, $output ) {
		$labels = $this->labels( $lang );

		$content  = "0.06 0.36 0.32 rg\n0 792 595 50 re\nf\n"; // Header band.
		$content .= $this->text( 'F2', 22, 40, 810, $labels['title'], '1 1 1' );
		$content .= $this->text( 'F1', 9, 40, 796, $labels['brand'], '1 1 1' );

		$content .= $this->text( 'F1', 12, 40, 740, $labels['ticket'], '0.4 0.4 0.4' );
		$content .= $this->text( 'F2', 18, 40, 716, $ticket_num, '0.1 0.1 0.1' );

		$y = 670;
		$rows = array(
			array( $labels['name'], $name ),
			array( $labels['event'], $event_title ),
			array( $labels['date'], $date ),
			array( $labels['time'], $time ),
			array( $labels['venue'], $venue ),
			array( $labels['persons'], (string) $persons ),
		);

		foreach ( $rows as $row ) {
			$content .= $this->text( 'F1', 10, 40, $y, $row[0], '0.45 0.45 0.45' );
			$content .= $this->text( 'F2', 13, 40, $y - 16, $this->truncate( $row[1], 60 ), '0.1 0.1 0.1' );
			$content .= "0.85 0.85 0.85 RG\n0.5 w\n40 " . ( $y - 26 ) . " m 555 " . ( $y - 26 ) . " l S\n";
			$y -= 56;
		}

		// QR code (vector).
		$qr_size = 200;
		$qr_x    = ( 595 - $qr_size ) / 2;
		$qr_y    = 150;
		$content .= "1 1 1 rg\n" . $qr_x . ' ' . $qr_y . ' ' . $qr_size . ' ' . $qr_size . " re\nf\n";
		$content .= YENA_QR::pdf_rects( $verify_link, $qr_x, $qr_y, $qr_size, 4 );

		$content .= $this->text( 'F2', 11, 40, 125, $labels['info'], '0.1 0.1 0.1' );
		$content .= $this->text( 'F1', 9, 40, 108, $labels['info2'], '0.35 0.35 0.35' );
		$content .= $this->text( 'F1', 7, 40, 60, $this->truncate( $verify_link, 110 ), '0.55 0.55 0.55' );

		return $this->write( $content, $output );
	}

	/**
	 * Assemble and save the PDF.
	 *
	 * @param string $content Page content stream.
	 * @param string $output  Output path.
	 * @return bool
	 */
	private function write( $content, $output ) {
		$dir = dirname( $output );
		if ( ! is_dir( $dir ) ) {
			@mkdir( $dir, 0755, true ); // phpcs:ignore
		}

		$stream = gzcompress( $content, 9 );

		$objects   = array();
		$objects[] = '<< /Type /Catalog /Pages 2 0 R >>';
		$objects[] = '<< /Type /Pages /Kids [3 0 R] /Count 1 >>';
		$objects[] = '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 5 0 R /F2 6 0 R >> >> /Contents 4 0 R >>';
		$objects[] = '<< /Length ' . strlen( $stream ) . " /Filter /FlateDecode >>\nstream\n" . $stream . "\nendstream";
		$objects[] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';
		$objects[] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';

		$pdf     = "%PDF-1.4\n";
		$offsets = array();

		foreach ( $objects as $index => $object ) {
			$offsets[ $index + 1 ] = strlen( $pdf );
			$pdf                  .= ( $index + 1 ) . " 0 obj\n" . $object . "\nendobj\n";
		}

		$xref_offset = strlen( $pdf );
		$count       = count( $objects ) + 1;

		$pdf .= "xref\n0 " . $count . "\n";
		$pdf .= "0000000000 65535 f \n";
		for ( $i = 1; $i < $count; $i++ ) {
			$pdf .= sprintf( "%010d 00000 n \n", $offsets[ $i ] );
		}

		$pdf .= "trailer\n<< /Size " . $count . " /Root 1 0 R >>\nstartxref\n" . $xref_offset . "\n%%EOF\n";

		return false !== @file_put_contents( $output, $pdf ); // phpcs:ignore
	}

	/**
	 * Build a text drawing command.
	 *
	 * @param string $font  Font resource name.
	 * @param int    $size  Font size.
	 * @param float  $x     X position.
	 * @param float  $y     Y position.
	 * @param string $value Text.
	 * @param string $rgb   Fill colour.
	 * @return string
	 */
	private function text( $font, $size, $x, $y, $value, $rgb = '0 0 0' ) {
		$value = $this->encode( (string) $value );
		if ( '' === $value ) {
			return '';
		}

		return $rgb . " rg\nBT /" . $font . ' ' . $size . ' Tf ' . $x . ' ' . $y . ' Td (' . $value . ") Tj ET\n";
	}

	/**
	 * Convert UTF-8 text to a WinAnsi-safe PDF string.
	 *
	 * @param string $value Raw text.
	 * @return string
	 */
	private function encode( $value ) {
		$value = trim( $value );

		// Arabic or other non WinAnsi characters cannot be rendered with the
		// built-in PDF fonts; they are dropped instead of producing garbage.
		$value = preg_replace( '/[^\x20-\x7E\xA0-\xFF]/u', '', $value );
		$value = str_replace( array( '\\', '(', ')' ), array( '\\\\', '\\(', '\\)' ), $value );

		return $value;
	}

	/**
	 * Shorten a string for single-line display.
	 *
	 * @param string $value Text.
	 * @param int    $max   Maximum characters.
	 * @return string
	 */
	private function truncate( $value, $max ) {
		$value = (string) $value;
		if ( strlen( $value ) <= $max ) {
			return $value;
		}

		return substr( $value, 0, $max - 3 ) . '...';
	}

	/**
	 * Labels for the ticket PDF.
	 *
	 * @param string $lang Language code.
	 * @return array
	 */
	private function labels( $lang ) {
		$brand = 'Arab Kulturfestival';

		if ( 'ar' === $lang ) {
			// The built-in PDF fonts cannot render Arabic, so the PDF uses
			// English labels while the e-mail itself stays fully Arabic.
			$lang = 'en';
		}

		if ( 'en' === $lang ) {
			return array(
				'brand'   => $brand,
				'title'   => 'Entry Ticket',
				'name'    => 'Name',
				'event'   => 'Event',
				'date'    => 'Date',
				'time'    => 'Time',
				'venue'   => 'Venue',
				'persons' => 'Persons',
				'ticket'  => 'Ticket Number',
				'info'    => 'Present this QR code at the entrance.',
				'info2'   => 'The QR code is personal and will be scanned once at the door.',
			);
		}

		return array(
			'brand'   => $brand,
			'title'   => 'Eintrittskarte',
			'name'    => 'Name',
			'event'   => 'Veranstaltung',
			'date'    => 'Datum',
			'time'    => 'Uhrzeit',
			'venue'   => 'Ort',
			'persons' => 'Personen',
			'ticket'  => 'Ticket-Nummer',
			'info'    => 'Bitte zeigen Sie diesen QR-Code am Einlass vor.',
			'info2'   => 'Der QR-Code ist persönlich und wird am Eingang einmalig gescannt.',
		);
	}
}
