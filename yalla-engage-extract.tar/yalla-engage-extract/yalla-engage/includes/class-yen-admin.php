<?php
/**
 * Admin interface for Yalla Engage: single menu "النشرة والتسجيل" with 6 pages.
 *
 * @package Yalla_Engage
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin interface.
 */
class YENA_Admin {

	protected static $instance = null;

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public static function init() {
		$instance = self::get_instance();

		add_action( 'init', array( $instance, 'add_roles' ) );
		add_action( 'admin_menu', array( $instance, 'add_menu' ) );

		add_action( 'admin_post_yena_save_settings', array( $instance, 'save_settings' ) );
		add_action( 'admin_post_yena_export_subscribers', array( $instance, 'export_subscribers' ) );
		add_action( 'admin_post_yena_export_registrations', array( $instance, 'export_registrations' ) );
		add_action( 'admin_post_yena_delete_subscriber', array( $instance, 'delete_subscriber' ) );
		add_action( 'admin_post_yena_cancel_registration', array( $instance, 'cancel_registration' ) );
		add_action( 'admin_post_yena_test_mail', array( $instance, 'test_mail' ) );
		add_action( 'admin_post_yena_checkin_verify', array( $instance, 'checkin_verify' ) );

		add_action( 'admin_notices', array( $instance, 'admin_notices' ) );

		// Poster image meta box for events.
		add_action( 'add_meta_boxes', array( $instance, 'add_poster_meta_box' ) );
		add_action( 'save_post', array( $instance, 'save_poster_meta_box' ) );

		// Enqueue media uploader for poster meta box
		add_action( 'admin_enqueue_scripts', array( $instance, 'enqueue_poster_media' ) );
	}

	public function add_roles() {
		$role = get_role( 'yena_manager' );
		if ( ! $role ) {
			add_role(
				'yena_manager',
				__( 'مدير النشرة والتسجيل', 'yalla-engage' ),
				array(
					'read'         => true,
					'yena_manage'  => true,
					'edit_posts'   => false,
					'publish_posts'=> false,
				)
			);
		}
		$editor = get_role( 'editor' );
		if ( $editor ) {
			$editor->add_cap( 'yena_manage' );
		}
		$admin = get_role( 'administrator' );
		if ( $admin ) {
			$admin->add_cap( 'yena_manage' );
		}
	}

	public function add_menu() {
		add_menu_page(
			__( 'النشرة والتسجيل', 'yalla-engage' ),
			__( 'النشرة والتسجيل', 'yalla-engage' ),
			'yena_manage',
			'yena-dashboard',
			array( $this, 'render_dashboard' ),
			'dashicons-email-alt',
			26
		);

		add_submenu_page( 'yena-dashboard', __( 'المشتركون', 'yalla-engage' ), __( 'المشتركون', 'yalla-engage' ), 'yena_manage', 'yena-subscribers', array( $this, 'render_subscribers' ) );
		add_submenu_page( 'yena-dashboard', __( 'النشرات', 'yalla-engage' ), __( 'النشرات', 'yalla-engage' ), 'yena_manage', 'yena-campaigns', array( $this, 'render_campaigns' ) );
		add_submenu_page( 'yena-dashboard', __( 'التسجيلات', 'yalla-engage' ), __( 'التسجيلات', 'yalla-engage' ), 'yena_manage', 'yena-registrations', array( $this, 'render_registrations' ) );
		add_submenu_page( 'yena-dashboard', __( 'التحقق من التذاكر', 'yalla-engage' ), __( 'التحقق من التذاكر', 'yalla-engage' ), 'yena_manage', 'yena-checkin', array( $this, 'render_checkin' ) );
		add_submenu_page( 'yena-dashboard', __( 'الإعدادات', 'yalla-engage' ), __( 'الإعدادات', 'yalla-engage' ), 'yena_manage', 'yena-settings', array( $this, 'render_settings' ) );
		add_submenu_page( 'yena-dashboard', __( 'فحص البريد', 'yalla-engage' ), __( 'فحص البريد', 'yalla-engage' ), 'yena_manage', 'yena-test-mail', array( $this, 'render_test_mail' ) );
		add_submenu_page( 'yena-dashboard', __( 'مساعدة', 'yalla-engage' ), __( 'مساعدة', 'yalla-engage' ), 'yena_manage', 'yena-help', array( $this, 'render_help' ) );
	}

	/* ------------------------------------------------------------------ */
	/* Dashboard                                                          */
	/* ------------------------------------------------------------------ */

	public function render_dashboard() {
		global $wpdb;
		$subs   = YENA_DB::subscribers();
		$regs   = YENA_DB::registrations();
		$camp   = YENA_DB::campaigns();

		$confirmed = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$subs} WHERE status = 'confirmed'" );
		$pending   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$subs} WHERE status = 'pending'" );
		$events    = $wpdb->get_results( "SELECT ID, post_title FROM {$wpdb->posts} WHERE post_type = 'yd_event' AND post_status = 'publish' ORDER BY post_date ASC LIMIT 5" );
		$last_camp = $wpdb->get_row( "SELECT * FROM {$camp} ORDER BY id DESC LIMIT 1" );
		$last_regs = $wpdb->get_results( "SELECT * FROM {$regs} ORDER BY id DESC LIMIT 5" );

		// Attendance stats.
		$total_regs = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$regs} WHERE status = 'confirmed'" );
		$checked_in = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$regs} WHERE status = 'checked_in'" );

		include YENA_DIR . '/templates/dashboard.php';
	}

	/* ------------------------------------------------------------------ */
	/* Subscribers                                                        */
	/* ------------------------------------------------------------------ */

	public function render_subscribers() {
		global $wpdb;
		$table = YENA_DB::subscribers();

		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
		$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
		$lang   = isset( $_GET['lang'] ) ? sanitize_key( wp_unslash( $_GET['lang'] ) ) : '';

		$where = array();
		if ( $search ) {
			$where[] = $wpdb->prepare( "(email LIKE %s OR name LIKE %s)", '%' . $wpdb->esc_like( $search ) . '%', '%' . $wpdb->esc_like( $search ) . '%' );
		}
		if ( $status ) {
			$where[] = $wpdb->prepare( "status = %s", $status );
		}
		if ( $lang ) {
			$where[] = $wpdb->prepare( "lang = %s", $lang );
		}
		$sql_where = $where ? 'WHERE ' . implode( ' AND ', $where ) : '';

		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} {$sql_where}" );
		$rows  = $wpdb->get_results( "SELECT * FROM {$table} {$sql_where} ORDER BY id DESC LIMIT 50" );

		include YENA_DIR . '/templates/subscribers.php';
	}

	/* ------------------------------------------------------------------ */
	/* Campaigns                                                          */
	/* ------------------------------------------------------------------ */

	public function render_campaigns() {
		global $wpdb;
		$table = YENA_DB::campaigns();
		$rows  = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY id DESC LIMIT 50" );
		include YENA_DIR . '/templates/campaigns.php';
	}

	/* ------------------------------------------------------------------ */
	/* Registrations                                                      */
	/* ------------------------------------------------------------------ */

	public function render_registrations() {
		global $wpdb;
		$table = YENA_DB::registrations();

		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
		$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';

		$where = array();
		if ( $search ) {
			$where[] = $wpdb->prepare( "(name LIKE %s OR email LIKE %s OR ticket_number LIKE %s)", '%' . $wpdb->esc_like( $search ) . '%', '%' . $wpdb->esc_like( $search ) . '%', '%' . $wpdb->esc_like( $search ) . '%' );
		}
		if ( $status ) {
			$where[] = $wpdb->prepare( "status = %s", $status );
		}
		$sql_where = $where ? 'WHERE ' . implode( ' AND ', $where ) : '';

		$total   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} {$sql_where}" );
		$checked = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status = 'checked_in'" );
		$rows    = $wpdb->get_results( "SELECT * FROM {$table} {$sql_where} ORDER BY id DESC LIMIT 100" );

		include YENA_DIR . '/templates/registrations.php';
	}

	/* ------------------------------------------------------------------ */
	/* Check-in page (entrance verification)                              */
	/* ------------------------------------------------------------------ */

	public function render_checkin() {
		if ( ! current_user_can( 'yena_manage' ) ) {
			wp_die( esc_html__( 'غير مسموح.', 'yalla-engage' ) );
		}
		include YENA_DIR . '/templates/checkin.php';
	}

	public function checkin_verify() {
		if ( ! current_user_can( 'yena_manage' ) ) {
			wp_die( esc_html__( 'غير مسموح.', 'yalla-engage' ) );
		}
		check_admin_referer( 'yena_checkin' );

		$reg_id = isset( $_POST['yena_reg_id'] ) ? absint( $_POST['yena_reg_id'] ) : 0;
		$persons = isset( $_POST['yena_checkin_persons'] ) ? absint( $_POST['yena_checkin_persons'] ) : 1;

		if ( $reg_id ) {
			global $wpdb;
			$table = YENA_DB::registrations();
			$wpdb->update(
				$table,
				array(
					'status'           => 'checked_in',
					'checked_in_at'    => current_time( 'mysql', true ),
					'checked_in_by'    => get_current_user_id(),
					'checked_in_persons' => $persons,
				),
				array( 'id' => $reg_id ),
				array( '%s', '%s', '%d', '%d' )
			);
			add_post_meta( $reg_id, 'yena_checked_in', '1', true );
			add_post_meta( $reg_id, 'yena_checked_in_at', current_time( 'mysql', true ), true );
			add_post_meta( $reg_id, 'yena_checked_in_by', get_current_user_id(), true );
		}

		wp_redirect( admin_url( 'admin.php?page=yena-checkin&checked=1' ) );
		exit;
	}

	/* ------------------------------------------------------------------ */
	/* Settings                                                           */
	/* ------------------------------------------------------------------ */

	public function render_settings() {
		$settings = get_option( 'yena_settings', array() );
		include YENA_DIR . '/templates/settings.php';
	}

	public function save_settings() {
		if ( ! current_user_can( 'yena_manage' ) ) {
			wp_die( __( 'غير مسموح.', 'yalla-engage' ) );
		}
		check_admin_referer( 'yena_settings' );

		$settings = array();
		$settings['notify_email'] = isset( $_POST['yena_notify_email'] ) ? sanitize_email( wp_unslash( $_POST['yena_notify_email'] ) ) : '';
		$settings['batch_size']   = isset( $_POST['yena_batch_size'] ) ? absint( $_POST['yena_batch_size'] ) : 20;
		$settings['reminder']     = isset( $_POST['yena_reminder'] ) ? '1' : '0';

		$texts = array();
		foreach ( array( 'de', 'en', 'ar' ) as $lang ) {
			$texts[ $lang ] = array();
			foreach ( array(
				'news_confirm_subject', 'news_confirm_body', 'news_welcome_subject', 'news_welcome_body',
				'news_pending', 'news_confirmed', 'news_already', 'news_error', 'news_invalid',
				'news_unsubscribed', 'news_rate', 'news_mail_fail',
				'reg_confirm_subject', 'reg_confirm_body', 'reg_admin_subject',
				'reg_ok', 'reg_ok_nomail', 'reg_full', 'reg_already', 'reg_cancelled',
				'reg_error', 'reg_invalid', 'reg_closed', 'reg_rate',
				'campaign_subject', 'campaign_body',
			) as $key ) {
				$post_key = 'yena_text_' . $lang . '_' . $key;
				if ( isset( $_POST[ $post_key ] ) ) {
					$texts[ $lang ][ $key ] = wp_unslash( $_POST[ $post_key ] );
				}
			}
		}
		$settings['texts'] = $texts;

		update_option( 'yena_settings', $settings );

		add_settings_error( 'yena', 'yena-saved', __( 'تم حفظ الإعدادات بنجاح.', 'yalla-engage' ), 'updated' );
		wp_redirect( admin_url( 'admin.php?page=yena-settings&yena-saved=1' ) );
		exit;
	}

	/* ------------------------------------------------------------------ */
	/* Export                                                             */
	/* ------------------------------------------------------------------ */

	public function export_subscribers() {
		if ( ! current_user_can( 'yena_manage' ) ) {
			wp_die( __( 'غير مسموح.', 'yalla-engage' ) );
		}
		check_admin_referer( 'yena_export' );

		global $wpdb;
		$table = YENA_DB::subscribers();
		$rows  = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY id DESC" );

		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="yena_subscribers.csv"' );
		header( 'Cache-Control: no-cache' );

		$out = fopen( 'php://output', 'w' );
		fputcsv( $out, array( 'ID', 'البريد الإلكتروني', 'الاسم', 'اللغة', 'الحالة', 'تاريخ الإنشاء' ), "\t", '"' );
		foreach ( $rows as $row ) {
			fputcsv( $out, array( $row->id, $row->email, $row->name, $row->lang, $row->status, $row->created_at ), "\t", '"' );
		}
		fclose( $out );
		exit;
	}

	public function export_registrations() {
		if ( ! current_user_can( 'yena_manage' ) ) {
			wp_die( __( 'غير مسموح.', 'yalla-engage' ) );
		}
		check_admin_referer( 'yena_export' );

		global $wpdb;
		$table = YENA_DB::registrations();
		$rows  = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY id DESC" );

		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="yena_registrations.csv"' );
		header( 'Cache-Control: no-cache' );

		$out = fopen( 'php://output', 'w' );
		fputcsv( $out, array( 'ID', 'الفعالية', 'الاسم', 'البريد الإلكتروني', 'الهاتف', 'الأفراد', 'اللغة', 'الحالة', 'تاريخ الإنشاء', 'حضر/لم يحضر', 'رقم التذكرة' ), "\t", '"' );
		foreach ( $rows as $row ) {
			$title = get_the_title( $row->event_id );
			$attended = ( 'checked_in' === $row->status ) ? 'حضر' : 'لم يحضر';
			fputcsv( $out, array( $row->id, $title, $row->name, $row->email, $row->phone, $row->persons, $row->lang, $row->status, $row->created_at, $attended, $row->ticket_number ), "\t", '"' );
		}
		fclose( $out );
		exit;
	}

	/* ------------------------------------------------------------------ */
	/* Delete / cancel                                                    */
	/* ------------------------------------------------------------------ */

	public function delete_subscriber() {
		if ( ! current_user_can( 'yena_manage' ) ) {
			wp_die( __( 'غير مسموح.', 'yalla-engage' ) );
		}
		check_admin_referer( 'yena_delete' );

		$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		global $wpdb;
		$table = YENA_DB::subscribers();
		$wpdb->delete( $table, array( 'id' => $id ), array( '%d' ) );

		wp_redirect( admin_url( 'admin.php?page=yena-subscribers&deleted=1' ) );
		exit;
	}

	public function cancel_registration() {
		if ( ! current_user_can( 'yena_manage' ) ) {
			wp_die( __( 'غير مسموح.', 'yalla-engage' ) );
		}
		check_admin_referer( 'yena_cancel' );

		$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		global $wpdb;
		$table = YENA_DB::registrations();
		$wpdb->update( $table, array( 'status' => 'cancelled' ), array( 'id' => $id ), array( '%s' ) );

		wp_redirect( admin_url( 'admin.php?page=yena-registrations&cancelled=1' ) );
		exit;
	}

	/* ------------------------------------------------------------------ */
	/* Test mail                                                          */
	/* ------------------------------------------------------------------ */

	public function render_test_mail() {
		$result = '';
		if ( isset( $_GET['yena-tested'] ) ) {
			$result = sanitize_text_field( wp_unslash( $_GET['yena-tested'] ) );
		}
		include YENA_DIR . '/templates/test-mail.php';
	}

	public function test_mail() {
		if ( ! current_user_can( 'yena_manage' ) ) {
			wp_die( __( 'غير مسموح.', 'yalla-engage' ) );
		}
		check_admin_referer( 'yena_test' );

		$to = isset( $_POST['yena_test_email'] ) ? sanitize_email( wp_unslash( $_POST['yena_test_email'] ) ) : get_option( 'admin_email' );
		$subject = 'اختبار إرسال بريد — ' . get_bloginfo( 'name' );
		$html = YENA_Emails::template( '<p>هذه رسالة اختبار من إضافة Yalla Engage. إذا وصلتك هذه الرسالة، يعمل الإرسال بشكل طبيعي.</p>', 'ar' );
		$text = "هذه رسالة اختبار من إضافة Yalla Engage. إذا وصلتك هذه الرسالة، يعمل الإرسال بشكل طبيعي.";

		$sent = YENA_Emails::send( $to, $subject, $html, $text );

		$status = $sent ? 'success' : 'fail';
		wp_redirect( admin_url( 'admin.php?page=yena-test-mail&yena-tested=' . $status ) );
		exit;
	}

	/* ------------------------------------------------------------------ */
	/* Help                                                               */
	/* ------------------------------------------------------------------ */

	public function render_help() {
		include YENA_DIR . '/templates/help.php';
	}

	/* ------------------------------------------------------------------ */
	/* Notices                                                            */
	/* ------------------------------------------------------------------ */

	public function admin_notices() {
	}
}

/* ------------------------------------------------------------------ */
/* Media uploader for poster meta box                                 */
/* ------------------------------------------------------------------ */

function enqueue_poster_media() {
	global $post_type;
	if ( 'yd_event' === $post_type ) {
		wp_enqueue_media();
	}
}

function add_poster_meta_box( $post_type, $post ) {
	if ( 'yd_event' !== $post_type ) {
		return;
	}

	$poster_url = get_post_meta( $post->ID, 'yena_poster_image', true );
	$title    = __( 'صورة البوستر', 'yena' );
	$context  = 'normal';
	$priority = 'high';

	// WordPress >= 5.5 uses 'use_block_editor' but we check manually
	if ( function_exists( 'wp_is_using_block_editor' ) && ! wp_is_using_block_editor( $post_type ) ) {
		$context = 'side';
	}

	add_meta_box( 'yena_poster_meta', $title, array( $this, 'poster_meta_box_callback' ), $post_type, $context, $priority );
}

function poster_meta_box_callback( $post ) {
	$poster_url = esc_url_raw( get_post_meta( $post->ID, 'yena_poster_image', true ) );
	?>
	<p style="margin:0 0 10px 0;font-size:12px;color:#666;">
		<?php echo esc_html__( 'اسم الملف والصيغة: JPG, PNG, WebP (موصى به)', 'yena' ); ?>
	</p>
	<p style="margin:0 0 10px 0;font-size:12px;color:#666;">
		<?php echo esc_html__( 'حجم الصورة الموصى به: ما لا يزيد عن 2MB', 'yena' ); ?>
	</p>
	<input type="hidden" name="yena_poster_meta_nonce" value="<?php echo wp_create_nonce( 'yena_poster_meta' ); ?>">
	<input type="text" name="yena_poster_image" style="width:100%;padding:8px;margin-bottom:8px;border:1px solid #ddd;border-radius:4px;background:#fafafa;"
		value="<?php echo esc_attr( $poster_url ); ?>"
		onfocus="this.select();"
		placeholder="<?php echo esc_attr__( 'رابط صورة البوستر (URL)', 'yena' ); ?>">
	<button type="button" class="button secondary yena-poster-upload-btn"
	style="width:100%;padding:8px;margin-top:8px">
		<?php echo esc_attr__( 'تحميل صورة', 'yena' ); ?>
	</button>
	<script type="text/javascript">
	jQuery(document).ready(function($) {
		$('.yena-poster-upload-btn').on('click', function() {
			var input = $(this).prev('input');
			wp.media.editor.send.attachment({}, function(view, model) {
				var url = model.get('url');
				input.val( url );
			}).open();
		});
	});
	</script>
	<?php
}

function save_poster_meta_box( $post_id ) {
	// Ignore auto-save
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}

	// Check nonce
	if ( ! isset( $_POST['yena_poster_meta_nonce'] ) || ! wp_verify_nonce( $_POST['yena_poster_meta_nonce'], 'yena_poster_meta' ) ) {
		return;
	}

	// Check permissions
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	if ( isset( $_POST['yena_poster_image'] ) ) {
		$url = esc_url_raw( $_POST['yena_poster_image'] );
		update_post_meta( $post_id, 'yena_poster_image', $url );
	}
}