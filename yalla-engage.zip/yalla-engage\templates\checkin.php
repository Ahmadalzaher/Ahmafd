<?php
/**
 * Check-in page for event registration (entrance verification).
 * Mobile-friendly, manager-only page with QR scanner and manual entry.
 *
 * @package Yalla_Engage
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! current_user_can( 'yena_manage' ) ) {
	wp_die( esc_html__( 'هذه الصفحة تتطلب تسجيل الدخول وصلاحية "مدير النشرة والتسجيل".', 'yalla-engage' ) );
}

$verify_msg   = '';
$verify_class = '';
$ticket_data  = null;

if ( isset( $_GET['yena_verify'] ) && '1' === sanitize_key( wp_unslash( $_GET['yena_verify'] ) ) ) {
	$code = isset( $_GET['code'] ) ? sanitize_text_field( wp_unslash( $_GET['code'] ) ) : '';
	if ( $code ) {
		global $wpdb;
		$table = YENA_DB::registrations();
		$reg   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE token = %s OR ticket_code = %s", $code, $code ) );
		if ( $reg ) {
			$event = get_post( $reg->event_id );
			if ( 'cancelled' === $reg->status ) {
				$verify_msg   = esc_html__( 'هذه التذكرة ملغاة.', 'yalla-engage' );
				$verify_class = 'verify--red';
			} elseif ( '1' === get_post_meta( $reg->id, 'yena_checked_in', true ) ) {
				$verify_msg   = sprintf(
					esc_html__( 'هذه التذكرة مستخدمة بالفعل (تم الدخول في %s).', 'yalla-engage' ),
					esc_html( get_post_meta( $reg->id, 'yena_checked_in_at', true ) )
				);
				$verify_class = 'verify--red';
			} elseif ( $reg->event_id && $event && 'publish' === $event->post_status ) {
				$ticket_data = array(
					'id'       => $reg->id,
					'name'     => $reg->name,
					'email'    => $reg->email,
					'persons'  => $reg->persons,
					'event'    => get_the_title( $reg->event_id ),
					'date'     => get_post_meta( $reg->event_id, '_yd_date', true ),
					'time'     => get_post_meta( $reg->event_id, '_yd_time', true ),
					'venue'    => implode( ', ', array_filter( array( get_post_meta( $reg->event_id, '_yd_venue', true ), get_post_meta( $reg->event_id, '_yd_city', true ) ) ) ),
					'token'    => $reg->token,
				);
				$verify_msg   = esc_html__( 'التذكرة صالحة. أكد الدخول أدناه.', 'yalla-engage' );
				$verify_class = 'verify--green';
			} else {
				$verify_msg   = esc_html__( 'هذه التذكرة غير صالحة لهذه الفعالية.', 'yalla-engage' );
				$verify_class = 'verify--yellow';
			}
		} else {
			$verify_msg   = esc_html__( 'التذكرة غير موجودة.', 'yalla-engage' );
			$verify_class = 'verify--red';
		}
	}
}

// Handle check-in confirmation.
if ( isset( $_POST['yena_checkin_nonce'] ) && wp_verify_nonce( sanitize_key( wp_unslash( $_POST['yena_checkin_nonce'] ) ), 'yena_checkin' ) && current_user_can( 'yena_manage' ) ) {
	$reg_id = isset( $_POST['yena_reg_id'] ) ? absint( $_POST['yena_reg_id'] ) : 0;
	$persons = isset( $_POST['yena_checkin_persons'] ) ? absint( $_POST['yena_checkin_persons'] ) : 1;
	if ( $reg_id ) {
		global $wpdb;
		$table = YENA_DB::registrations();
		$wpdb->update(
			$table,
			array(
				'status'           => 'checked_in',
				'checked_in_at'    => current_time( 'mysql', true ),
				'checked_in_by'    => get_current_user_id(),
				'checked_in_persons' => $persons,
			),
			array( 'id' => $reg_id ),
			array( '%s', '%s', '%d', '%d' )
		);
		add_post_meta( $reg_id, 'yena_checked_in', '1', true );
		add_post_meta( $reg_id, 'yena_checked_in_at', current_time( 'mysql', true ), true );
		add_post_meta( $reg_id, 'yena_checked_in_by', get_current_user_id(), true );
		$verify_msg   = esc_html__( 'تم تأكيد الدخول بنجاح.', 'yalla-engage' );
		$verify_class = 'verify--green';
		$ticket_data  = null;
	}
}
?>
<!DOCTYPE html>
<html lang="<?php echo esc_attr( function_exists( 'yd_lang' ) ? yd_lang() : 'ar' ); ?>" dir="<?php echo esc_attr( function_exists( 'yd_is_rtl' ) && yd_is_rtl() ? 'rtl' : 'ltr' ); ?>">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<title><?php echo esc_html__( 'التحقق من التذاكر عند الباب', 'yalla-engage' ); ?></title>
	<style>
		* { box-sizing: border-box; }
		body { font-family: Tahoma, Arial, sans-serif; margin: 0; padding: 12px; background: #f5f1ea; }
		html[dir="rtl"] body { direction: rtl; }
		.container { max-width: 480px; margin: 0 auto; background: #fff; border-radius: 12px; padding: 16px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
		h1 { font-size: 1.5rem; margin: 0 0 16px; color: #c84b31; text-align: center; }
		.scan-btn { width: 100%; padding: 18px; font-size: 1.1rem; background: #c84b31; color: #fff; border: none; border-radius: 8px; cursor: pointer; margin-bottom: 12px; font-weight: 700; }
		.scan-btn:hover { background: #a63d27; }
		.scan-btn:active { transform: scale(0.98); }
		.input-group { margin-bottom: 12px; }
		.input-group label { display: block; font-size: 0.9rem; font-weight: 700; margin-bottom: 6px; color: #555; }
		.input-group input { width: 100%; padding: 12px; font-size: 1rem; border: 1px solid #ccc; border-radius: 8px; }
		.checkin-btn { width: 100%; padding: 16px; font-size: 1rem; background: #6d9c76; color: #fff; border: none; border-radius: 8px; cursor: pointer; font-weight: 700; margin-top: 8px; }
		.checkin-btn:disabled { background: #ccc; cursor: not-allowed; }
		.verify-msg { padding: 12px; border-radius: 8px; margin-bottom: 16px; font-weight: 700; text-align: center; font-size: 1rem; }
		.verify--green { background: #eef5ea; color: #2d5a2d; border: 1px solid #6d9c76; }
		.verify--red { background: #fdecea; color: #8d2d2d; border: 1px solid #c84b31; }
		.verify--yellow { background: #fdf6ea; color: #8d6d2d; border: 1px solid #d9a441; }
		.ticket-card { border: 1px solid #e2d9c7; border-radius: 8px; padding: 16px; margin-top: 16px; background: #faf9f6; }
		.ticket-row { display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 0.95rem; }
		html[dir="rtl"] .ticket-row { flex-direction: row-reverse; }
		.ticket-row .label { font-weight: 700; color: #666; }
		.ticket-row .value { color: #222; }
		.persons-select { width: 100%; padding: 12px; font-size: 1rem; border: 1px solid #ccc; border-radius: 8px; margin-top: 8px; }
		.camera-preview { width: 100%; max-width: 320px; margin: 0 auto 12px; border: 2px solid #c84b31; border-radius: 8px; background: #000; display: none; }
		#scanner-container { margin-bottom: 16px; text-align: center; }
		.hide { display: none !important; }
		@media (max-width: 480px) {
			body { padding: 8px; }
			.container { padding: 12px; border-radius: 0; }
		}
	</style>
</head>
<body>
<div class="container">
	<h1><?php echo esc_html__( 'التحقق من التذاكر عند الباب', 'yalla-engage' ); ?></h1>

	<?php if ( $verify_msg ) : ?>
		<div class="verify-msg verify--<?php echo esc_attr( $verify_class === 'verify--green' ? 'green' : ( $verify_class === 'verify--yellow' ? 'yellow' : 'red' ) ); ?>">
			<?php echo esc_html( $verify_msg ); ?>
		</div>
	<?php endif; ?>

	<?php if ( $ticket_data ) : ?>
		<div class="ticket-card">
			<div class="ticket-row"><span class="label"><?php echo esc_html__( 'الفعالية', 'yalla-engage' ); ?></span><span class="value"><?php echo esc_html( $ticket_data['event'] ); ?></span></div>
			<div class="ticket-row"><span class="label"><?php echo esc_html__( 'الاسم', 'yalla-engage' ); ?></span><span class="value"><?php echo esc_html( $ticket_data['name'] ); ?></span></div>
			<div class="ticket-row"><span class="label"><?php echo esc_html__( 'عدد الأشخاص', 'yalla-engage' ); ?></span><span class="value"><?php echo esc_html( $ticket_data['persons'] ); ?></span></div>
			<div class="ticket-row"><span class="label"><?php echo esc_html__( 'التاريخ', 'yalla-engage' ); ?></span><span class="value"><?php echo esc_html( $ticket_data['date'] ); ?></span></div>
			<div class="ticket-row"><span class="label"><?php echo esc_html__( 'الوقت', 'yalla-engage' ); ?></span><span class="value"><?php echo esc_html( $ticket_data['time'] ); ?></span></div>
			<div class="ticket-row"><span class="label"><?php echo esc_html__( 'المكان', 'yalla-engage' ); ?></span><span class="value"><?php echo esc_html( $ticket_data['venue'] ); ?></span></div>
		</div>

		<form method="post" onsubmit="return confirm('<?php echo esc_js__( 'تأكيد دخول هذا المسجّل؟', 'yalla-engage' ); ?>');">
			<?php wp_nonce_field( 'yena_checkin', 'yena_checkin_nonce' ); ?>
			<input type="hidden" name="yena_reg_id" value="<?php echo (int) $ticket_data['id']; ?>">
			<label for="yena_checkin_persons"><?php echo esc_html__( 'عدد الحاضرين', 'yalla-engage' ); ?></label>
			<select name="yena_checkin_persons" class="persons-select" required>
				<?php for ( $i = 1; $i <= 10; $i++ ) : ?>
					<option value="<?php echo (int) $i; ?>" <?php selected( $i, $ticket_data['persons'] ); ?>><?php echo (int) $i; ?></option>
				<?php endfor; ?>
			</select>
			<button type="submit" class="checkin-btn"><?php echo esc_html__( 'تأكيد دخول', 'yalla-engage' ); ?></button>
		</form>
	<?php else : ?>
		<div id="scanner-container">
			<video id="camera-preview" class="camera-preview" autoplay playsinline></video>
			<button type="button" class="scan-btn" id="start-scan"><?php echo esc_html__( 'مسح رمز QR', 'yalla-engage' ); ?></button>
		</div>

		<div class="input-group">
			<label for="ticket-code-input"><?php echo esc_html__( 'أو أدخل رقم التذكرة', 'yalla-engage' ); ?></label>
			<input type="text" id="ticket-code-input" placeholder="<?php echo esc_attr__( 'YE-2026-0042 أو رمز التحقق', 'yalla-engage' ); ?>" autocomplete="off" />
		</div>
		<button type="button" class="checkin-btn" id="verify-manual"><?php echo esc_html__( 'تحقق', 'yalla-engage' ); ?></button>
	<?php endif; ?>

	<p style="text-align:center; font-size: 0.85rem; color: #888; margin-top: 16px;">
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=yena-registrations' ) ); ?>"><?php echo esc_html__( 'العودة إلى قائمة التسجيلات', 'yalla-engage' ); ?></a>
	</p>
</div>

<script src="<?php echo esc_url( YENA_URI . 'assets/js/jsqr.js' ); ?>"></script>
<script src="<?php echo esc_url( YENA_URI . 'assets/js/qr-scanner.js' ); ?>"></script>
<script>
(function(){
	var btn   = document.getElementById('start-scan');
	var video = document.getElementById('camera-preview');
	var input = document.getElementById('ticket-code-input');
	var manualBtn = document.getElementById('verify-manual');
	var container = document.getElementById('scanner-container');
	var streaming = false;

	if ( !btn || !video || !input || !manualBtn ) return;

	btn.addEventListener('click', function() {
		if ( streaming ) {
			var tracks = video.srcObject ? video.srcObject.getTracks() : [];
			tracks.forEach(function(t){ t.stop(); });
			video.srcObject = null;
			video.style.display = 'none';
			btn.textContent = '<?php echo esc_js__( 'مسح رمز QR', 'yalla-engage' ); ?>';
			streaming = false;
			return;
		}
		if ( !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia ) {
			alert('<?php echo esc_js__( 'الكاميرا غير مدعومة في هذا المتصفح. استخدم الإدخال اليدوي.', 'yalla-engage' ); ?>');
			return;
		}
		navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } })
			.then(function(stream) {
				video.srcObject = stream;
				video.style.display = 'block';
				btn.textContent = '<?php echo esc_js__( 'إيقاف المسح', 'yalla-engage' ); ?>';
				streaming = true;
				video.play();
				scanFrame();
			})
			.catch(function() {
				alert('<?php echo esc_js__( 'تعذر الوصول إلى الكاميرا. تأكد من منح الإذن.', 'yalla-engage' ); ?>');
			});
	});

	function scanFrame() {
		if ( !streaming || !video.srcObject ) return;
		if ( video.readyState === video.HAVE_ENOUGH_DATA ) {
			var canvas = document.createElement('canvas');
			canvas.width = video.videoWidth;
			canvas.height = video.videoHeight;
			var ctx = canvas.getContext('2d');
			ctx.drawImage(video, 0, 0);
			var imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
			var code = window.yenaQRScan ? window.yenaQRScan(imageData) : null;
			if ( code ) {
				var tracks = video.srcObject.getTracks();
				tracks.forEach(function(t){ t.stop(); });
				video.srcObject = null;
				video.style.display = 'none';
				btn.textContent = '<?php echo esc_js__( 'مسح رمز QR', 'yalla-engage' ); ?>';
				streaming = false;
				input.value = code;
				manualBtn.click();
				return;
			}
		}
		requestAnimationFrame(scanFrame);
	}

	manualBtn.addEventListener('click', function() {
		var code = input.value.trim();
		if ( !code ) return;
		var url = new URL(window.location.href);
		url.searchParams.set('yena_verify', '1');
		url.searchParams.set('code', code);
		window.location.href = url.toString();
	});

	input.addEventListener('keypress', function(e) {
		if (e.key === 'Enter') manualBtn.click();
	});
})();
</script>
</body>
</html>
